label scene_07_investigation:
    scene malfoy hall
    
    with Dissolve(1.5)
    # Перед этим Драко позвал Миппи.

    play music "audio/Candlelit Tension.mp3" loop fadein 3.0

    "Раздался негромкий хлопок."

    show mippy neutral 

    "Перед ними появилась пожилая домовичка."

    "Она аккуратно сложила руки перед собой и посмотрела на Драко."

    m "Мистер Драко звал Миппи?"

    hide mippy neutral

    show draco neutral2 

    d "Да."

    d "Добрый вечер, Миппи."

    d "Нам нужно задать тебе несколько вопросов."

    hide draco neutral2

    show mippy neutral 

    m "Конечно, мистер Драко."

    hide mippy neutral

    show draco neutral2 

    d "О моём отце."

    d "О той ночи, когда он умер."

    hide draco neutral2

    show mippy neutral 

    "Миппи заметно посерьёзнела."

    m "Миппи помнит ту ночь."

    hide mippy neutral

    show herm neutral 

    "Гермиона невольно посмотрела на Драко."

    "Она ожидала приказа."

    "Короткого, привычного чистокровному волшебнику: отвечай."

    "Но Драко лишь немного помедлил."

    hide herm neutral

    show draco neutral2 

    d "Если тебе неприятно об этом говорить, скажи."

    d "Нам нужны только факты, которые ты помнишь."

    hide draco neutral2

    show mippy neutral 

    m "Миппи всё расскажет, что сможет."

    hide mippy neutral

    show herm neutral 

    "Гермиона ничего не сказала."

    "Но отметила это."


    # --- НАРЦИССА ---

    h "Миппи, Нарцисса Малфой была в Мэноре в тот день?"

    hide herm neutral

    show mippy neutral 

    m "Не весь день, мисс."

    m "Госпожу Нарциссу утром вызвали в Министерство."

    hide mippy neutral

    show herm neutral 

    h "На допрос?"

    hide herm neutral

    show mippy neutral 

    m "Да, мисс."

    m "Госпожа вернулась поздно."

    m "Она была очень уставшая."

    "Миппи ненадолго задумалась."

    m "Очень тихая."

    m "Миппи помогла госпоже подняться наверх."

    hide mippy neutral

    show herm neutral 

    h "Она заходила к Люциусу после возвращения?"

    hide herm neutral

    show mippy neutral 

    m "Нет, мисс."

    m "Госпожа спросила, как мистер Люциус."

    m "А потом сказала, чтобы её разбудили, если ему станет хуже."

    m "И пошла в свою комнату."

    hide mippy neutral

    show herm neutral 

    h "И больше не выходила?"

    hide herm neutral

    show mippy neutral 

    m "Нет, до самого утра."

    "Гермиона задумалась."

    "Нарцисса была в доме."

    "Но если Миппи ничего не путала, большую часть последних часов жизни Люциуса она провела в своей спальне."


    # --- ЛЮЦИУС ---

    hide mippy neutral

    show herm neutral 

    h "Насколько плох был Люциус в тот вечер?"

    hide herm neutral

    show mippy neutral 

    "Миппи опустила взгляд."

    m "Очень плох, мисс."

    m "Мистер Люциус болел уже давно."

    hide mippy neutral

    show herm neutral 

    h "Целители знали причину?"

    hide herm neutral

    show mippy neutral 

    m "Миппи не знает, что говорили целители."

    m "Но в мистере Люциусе оставалась тёмная магия."

    m "После Тёмного Лорда."

    "Домовичка произнесла последние слова значительно тише."

    m "Она не уходила."

    m "Мистер становился всё слабее."

    hide mippy neutral

    show draco neutral2 

    d "Достаточно, Миппи."

    d "Тебе не нужно рассказывать о его болезни больше, чем ты помнишь."

    hide draco neutral2

    show mippy neutral 

    m "Миппи помнит, мистер Драко."

    hide mippy neutral

    show herm neutral 

    "Гермиона снова взглянула на Малфоя."

    "Она слишком хорошо помнила, как Люциус Малфой обращался с домовыми эльфами."

    "Драко явно не унаследовал от отца эту манеру."

    "От этой мысли ей почему-то стало немного теплее."


    # --- АВРОРЫ ---

    h "Ты говорила, что в доме были люди из Министерства."

    hide herm neutral

    show mippy neutral 

    m "Да, мисс."

    m "Много."

    hide mippy neutral

    show herm neutral 

    h "Авроры?"

    hide herm neutral

    show mippy neutral 

    m "Авроры."

    m "Они ходили по дому."

    m "Открывали комнаты."

    m "Спускались в подвалы."

    m "Просили показать хранилища."

    hide mippy neutral

    show draco neutral2 

    d "Просили?"

    hide draco neutral2

    show mippy neutral 

    "Миппи посмотрела на него."

    m "Миппи старается быть вежливой, мистер Драко."

    hide mippy neutral

    show draco neutral2 

    "На мгновение в глазах Драко мелькнула усмешка."

    d "Я понял."

    hide draco neutral2

    show herm neutral 

    h "Они оставались в Мэноре ночью?"

    hide herm neutral

    show mippy neutral 

    m "Да, мисс."

    m "Не все."

    m "Но несколько авроров оставались."

    hide mippy neutral

    show herm neutral 

    h "Они заходили к Люциусу?"

    hide herm neutral

    show mippy neutral 

    m "Раньше — да."

    m "В ту ночь Миппи не видела."

    hide mippy neutral

    show herm neutral 

    h "Кто тогда находился с ним?"


    # --- ТИББИ ---

    hide herm neutral

    show mippy neutral 

    m "Тибби."

    hide mippy neutral

    show herm neutral 

    "Гермиона замерла."

    h "Всю ночь?"

    hide herm neutral

    show mippy neutral 

    m "Почти."

    m "Мистер Люциус не хотел оставаться один."

    m "Тибби приносил ему воду."

    m "Лекарства."

    m "Поддерживал огонь."

    m "Он почти не выходил из комнаты."

    hide mippy neutral

    show herm neutral 

    h "А когда Люциус умер?"

    hide herm neutral

    show mippy neutral 

    "Миппи помолчала."

    m "Тибби был с ним."

    hide mippy neutral

    show draco neutral2 

    d "Ты уверена?"

    hide draco neutral2

    show mippy neutral 

    m "Да, мистер Драко."

    m "Тибби потом пришёл за Миппи."

    m "Сказал, что мистер Люциус больше не дышит."

    "В комнате стало очень тихо."

    hide mippy neutral

    show herm neutral 

    "Гермиона медленно поставила бокал на стол."

    h "Значит, Тибби был последним, кто видел Люциуса живым."

    hide herm neutral

    show mippy neutral 

    m "Да, мисс."

    hide mippy neutral

    show herm neutral 

    "Гермиона посмотрела на Драко."

    "Теперь это уже не было просто догадкой."

    "Человек — или, точнее, существо, — которое последним находилось рядом с Люциусом Малфоем..."

    "...никто так и не допросил."

    hide herm neutral

    show draco neutral2 

    "Драко встретил её взгляд."

    "Судя по его лицу, он подумал о том же."

    hide draco neutral2

    show herm neutral 
    "Гермиона на несколько секунд задумалась."

    h "Миппи, ты сказала, что авроры осматривали хранилища."

    h "Старое хранилище тёмных артефактов тоже?"

    hide herm neutral

    show mippy neutral 

    m "Да, мисс."

    m "Несколько раз."

    stop music fadeout 3.0

    play music "audio/Ticking Shadows.mp3" loop fadein 3.0


    hide mippy neutral

    show herm neutral 
    h "Несколько?"

    hide herm neutral

    show draco neutral2 

    d "О, эту комнату Министерство знает очень хорошо."

    d "Уже лет десять."

    hide draco neutral2

    show herm neutral 
    "Гермиона проигнорировала его тон."

    h "После обыска составляли протокол изъятия?"

    hide herm neutral

    show draco neutral2 

    d "Разумеется."

    d "Министерство забрало всё содержимое комнаты."

    d "А взамен любезно оставило нам несколько листов пергамента с перечнем того, что раньше принадлежало семье."

    hide draco neutral2

    show herm neutral 
    h "У тебя сохранилась опись?"

    hide herm neutral

    show draco neutral2 

    d "Да."

    h "Где?"

    d "Там же."

    hide draco neutral2

    show herm neutral 
    h "В хранилище?"

    hide herm neutral

    show draco neutral2 

    d "А где ещё?"

    d "Теперь там достаточно свободного места для хранения документов."

    "В его голосе было столько сухой язвительности, что Гермиона невольно подняла бровь."

    hide draco neutral2

    show herm neutral 
    h "Министерство изъяло только тёмные артефакты?"

    hide herm neutral

    show draco neutral2 

    "Драко коротко усмехнулся."

    d "Нет, Грейнджер."

    d "Министерство изъяло всё, что сочло необходимым изъять."

    d "Там действительно хранились вещи, к которым я бы и сейчас не советовал прикасаться голыми руками."

    d "Но вместе с ними исчезли фамильные украшения."

    d "Камни. Несколько старых гоблинских изделий. Коллекция отца."

    d "Вещи, единственным преступлением которых была их стоимость."

    hide draco neutral2

    show herm neutral 
    h "Конфискованное имущество должно было быть передано на хранение Министерству."

    hide herm neutral

    show draco neutral2 

    d "Должно было."

    "Он сделал небольшую паузу."

    d "Прекрасное выражение, правда?"

    hide draco neutral2

    show herm neutral 
    h "Ты проверял, что с ним стало?"

    hide herm neutral

    show draco neutral2 

    d "Пытался."

    d "Часть вещей числится в Министерстве."

    d "Часть была передана в другие отделы."

    d "Некоторые позже выставлялись на аукционы как конфискованное имущество."

    d "А у некоторых след теряется где-то между первым и вторым пунктом."

    hide draco neutral2

    show herm neutral 
    h "А деньги с аукционов?"

    hide herm neutral

    show draco neutral2 

    d "Если выяснишь — обязательно расскажи."

    d "Мне тоже любопытно."

    "На этот раз Гермиона ничего не ответила."

    "Ей слишком хорошо были знакомы министерские архивы, чтобы сразу счесть его подозрения паранойей."

    "Особенно архивы первых послевоенных месяцев."

    "Тогда конфискации проводились быстро, отделы менялись, дела передавались из рук в руки."

    "И далеко не каждая бумага в итоге оказывалась там, где должна была."

    hide draco neutral2

    show herm neutral 
    h "Я хочу посмотреть эту опись."

    hide herm neutral

    show draco neutral2 

    d "Не сомневался."

    hide draco neutral2

    show herm neutral 
    "Покои Люциуса могли сохранить то, чего не заметили авроры."

    "В старом хранилище лежала опись конфискованных вещей — возможно, трость исчезла вовсе не из Мэнора."

    "Но оставался и третий путь."

    "Перестать искать трость."

    "И попытаться понять, что происходило в доме в часы после смерти Люциуса."

    "У Гермионы было сразу несколько зацепок."

    "Времени до утра оставалось достаточно."

    "Но начать следовало с чего-то одного."

    menu:

        "Осмотреть покои Люциуса":
            jump scene_08_search_lucius_rooms

        "Проверить старое хранилище":
            jump scene_08_search_dark_storage

        "Восстановить события той ночи":
            jump scene_08_reconstruct_night

    stop music fadeout 3.0
