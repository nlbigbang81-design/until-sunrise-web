style epilogue_text:
    font "fonts/CormorantGaramond-Regular.ttf"
    size 58
    color "#30251c"
    xalign 0.5
    text_align 0.5
    xmaximum 850
    line_spacing 8
    slow_cps 35


screen epilogue_paragraph(text):
    text text:
        style "epilogue_text"
        xalign 0.5
        yalign 0.48


label epilogue_text(text):

    show screen epilogue_paragraph(text) with dissolve
    pause
    hide screen epilogue_paragraph with dissolve

    return