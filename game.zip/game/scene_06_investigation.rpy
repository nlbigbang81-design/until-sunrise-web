label scene_06_investigation:

    scene malfoy hall
    with Dissolve(1.5)

    play music "audio/Suspended Harmony.mp3" loop fadein 3.0
    
    show herm neutral 
    
    h "Кто из домовиков находился рядом с Люциусом чаще остальных?"

    hide herm neutral

    show draco neutral2 

    "Драко задумался."

    d "Тибби."

    d "Он служил отцу ещё до моего рождения."

    hide draco neutral2

    show herm neutral 

    h "Он был здесь в день его смерти?"

    hide herm neutral

    show draco neutral2 

    d "Полагаю, да."

    hide draco neutral2

    show herm neutral 

    h "Полагаешь?"

    hide herm neutral

    show draco neutral2 

    d "Я не составлял список присутствующих, Грейнджер."

    d "Но в последние месяцы Тибби почти постоянно находился при отце."

    hide draco neutral2

    show herm neutral 

    h "Значит, он мог видеть, что произошло."

    hide herm neutral

    show draco neutral2 

    d "Вероятно."

    hide draco neutral2

    show herm neutral 

    h "И что он сказал?"

    hide herm neutral

    show draco neutral2 

    d "Мне?"

    hide draco neutral2

    show herm neutral 

    h "Тебе. Аврорам. Кому-нибудь."

    hide herm neutral

    show draco neutral2 

    "Драко слегка нахмурился."

    d "Не знаю, разговаривали ли с ним авроры."

    hide draco neutral2

    show herm neutral 

    h "А Министерство?"

    hide herm neutral

    show draco neutral2 

    d "Авроры и были от Министерства."

    hide draco neutral2

    show herm neutral 

    h "Ты прекрасно понимаешь, о чём я."

    h "Его официально опрашивали?"

    hide herm neutral

    show draco neutral2 

    "Драко пожал плечами."

    d "Сомневаюсь."

    hide draco neutral2

    show herm neutral 

    h "Почему?"

    hide herm neutral

    show draco neutral2 

    d "Потому что это домовик."

    hide draco neutral2

    show herm neutral 

    "Гермиона задумчиво опустила бокал."

    h "Это не ответ."

    hide herm neutral

    show draco neutral2 

    d "Для Министерства того времени — вполне."

    d "Домовик Малфоев, которого предлагают использовать как свидетеля против Малфоев?"

    "Он покачал головой."

    d "Не думаю, что кому-то пришло бы в голову всерьёз рассчитывать на его показания."

    hide draco neutral2

    show herm neutral 

    h "Домовики способны отвечать на вопросы."

    hide herm neutral

    show draco neutral2 

    d "Я в курсе."

    hide draco neutral2

    show herm neutral 

    h "Тогда почему никто не спросил?"

    hide herm neutral

    show draco neutral2 

    d "Потому что десять лет назад половина людей, обыскивающих этот дом, относилась к домовикам примерно так же, как моя семья."

    "Он сделал короткую паузу."

    d "Возможно, вежливее."

    d "Но едва ли внимательнее."

    hide draco neutral2

    show herm neutral 

    "Гермиона поджала губы."

    h "А вторая половина?"

    hide herm neutral

    show draco neutral2 

    d "Считала, что домовик всё равно не станет свидетельствовать против хозяина."

    d "Особенно такой, как Тибби."

    hide draco neutral2

    show herm neutral 

    h "Что значит — такой?"

    hide herm neutral

    show draco neutral2 

    d "Преданный."

    d "До абсурда."

    d "Для него отец был центром вселенной."

    hide draco neutral2

    show herm neutral 

    h "Тем более с ним следовало поговорить."

    hide herm neutral

    show draco neutral2 

    d "Чтобы узнать что?"

    hide draco neutral2

    show herm neutral 

    h "Например, когда он в последний раз видел трость."

    hide herm neutral

    show draco neutral2 

    d "Допустим."

    hide draco neutral2

    show herm neutral 

    h "Брал ли её Люциус в тот день."

    h "Оставалась ли она в комнате после его смерти."

    h "Кто входил туда до прибытия авроров."

    h "Кто вообще прикасался к его вещам."

    hide herm neutral

    show draco neutral2 

    "Драко посмотрел на неё чуть внимательнее."

    d "Ты думаешь, он видел, как кто-то забрал трость?"

    hide draco neutral2

    show herm neutral 

    h "Я думаю, что он мог видеть хоть что-нибудь."

    h "И никто не удосужился спросить."

    hide herm neutral

    show draco neutral2 

    d "Я спрашивал."

    hide draco neutral2

    show herm neutral 

    "Гермиона замерла."

    h "Ты только что сказал, что ничего не знаешь."

    hide herm neutral

    show draco neutral2 

    d "Я сказал, что не знаю, допрашивало ли его Министерство."

    d "Когда меня отпустили, я пытался выяснить, что происходило здесь после смерти отца."

    hide draco neutral2

    show herm neutral 

    h "И ты говорил с Тибби?"

    hide herm neutral

    show draco neutral2 

    "Драко покачал головой."

    d "Не успел."

    d "Он умер до моего возвращения."

    hide draco neutral2

    show herm neutral 

    h "Когда?"

    hide herm neutral

    show draco neutral2 

    d "Через несколько недель после отца."

    d "Он был стар."

    d "И после его смерти..."

    "Драко на мгновение замолчал."

    d "Скажем так, он продержался недолго."

    hide draco neutral2

    show herm neutral 

    "Гермиона задумалась."

    h "Но остальные домовики были здесь."

    hide herm neutral

    show draco neutral2 

    d "Да."

    hide draco neutral2

    show herm neutral 

    h "И никто из них ничего не заметил?"

    hide herm neutral

    show draco neutral2 

    d "Грейнджер, если ты сейчас собираешься предположить, что один из домовиков украл трость..."

    hide draco neutral2

    show herm neutral 

    h "Я пока ничего не предполагаю."

    hide herm neutral

    show draco neutral2 

    d "По твоему лицу этого не скажешь."

    hide draco neutral2

    show herm neutral 

    h "Почему ты так уверен, что это невозможно?"

    hide herm neutral

    show draco neutral2 

    "Он посмотрел на неё так, будто ответ был очевиден."

    d "Потому что домовик не берёт вещи хозяина."

    hide draco neutral2

    show herm neutral 

    h "Не берёт?"

    hide herm neutral

    show draco neutral2 

    d "Без разрешения — нет."

    d "И уж точно не Тибби."

    d "Он скорее отрубил бы себе руку, чем украл что-нибудь у отца."

    hide draco neutral2

    show herm neutral 

    "Гермиона несколько секунд молчала."

    h "А если он не считал это кражей?"

    hide herm neutral

    show draco neutral2 

    "Драко нахмурился."

    d "Что?"

    hide draco neutral2

    show herm neutral 

    h "Ты сказал, что он был предан Люциусу."

    h "Предположим, после его смерти в дом приходят незнакомые волшебники."

    h "Открывают комнаты. Забирают вещи."

    h "Для тебя это был официальный обыск."

    h "Для него?"

    "Гермиона слегка подалась вперёд."

    h "Он вообще понимал, что Министерство имеет право всё это увозить?"

    hide herm neutral

    show draco neutral2 

    "Драко ничего не ответил."

    hide draco neutral2

    show herm neutral 

    h "Или он видел людей, которые пришли в дом его умершего хозяина и начали забирать его вещи?"

    hide herm neutral

    show draco neutral2 

    "Теперь Драко уже не выглядел раздражённым."

    "Он задумался."

    d "Тибби никогда бы не украл у отца."

    hide draco neutral2

    show herm neutral 

    h "Вот именно."

    h "А если он пытался сохранить вещь для него?"

    "Несколько секунд они молчали."

    "За окнами снова прогремел гром."

    hide herm neutral

    show draco neutral2 

    d "Нет."

    "Но на этот раз это прозвучало уже не так уверенно."

    hide draco neutral2

    show herm neutral 

    h "Позови кого-нибудь из домовиков."

    hide herm neutral

    show draco neutral2 

    d "Зачем?"

    hide draco neutral2

    show herm neutral 

    h "Потому что мы десять лет спрашиваем не тех людей."

    "Драко несколько мгновений смотрел на неё."

    "Затем поставил стакан на стол."

    hide herm neutral

    show draco neutral2 

    d "Хорошо."

    "Он повернул голову в сторону пустого холла."

    d "Миппи."

    stop music fadeout 3.0


    jump scene_07_investigation