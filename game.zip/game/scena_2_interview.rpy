﻿
label scena_2_interview:

   
    scene malfoy hall
    with Dissolve(1.5)

    play music "audio/A Matter of Style.mp3" loop fadein 3.0


    "Тяжёлые двери закрылись за ними, отрезая шум дождя."

    "В просторном холле стало почти непривычно тихо."

    "Гермиона сняла мокрое пальто и поправила ремень сумки."


    show herm  neutral
         

    h "Итак."

    h "Сегодня я представляю Отдел послевоенного надзора Министерства магии. Я заменяю Уилсона — он заболел."

    hide herm neutral
    show draco neutral 

    d "Как трагично."

    hide draco neutral
    show herm  neutral
         

    h "Малфой."

    "Она бросила на него предупреждающий взгляд и достала из сумки папку."

    h "В соответствии с постановлением о надзоре за лицами, участвовавшими в войне на стороне Волан-де-Морта," 
    "Министерство обязано проводить ежемесячную проверку."

    h "Проверка включает подтверждение места проживания," 
    "контроль соблюдения установленных ограничений и аудит предметов, находящихся в поместье."

    hide herm neutral
    show draco neutral 

    "Драко несколько секунд смотрел на неё молча."

    d "Грейнджер."

    d "Я нахожусь под пристальным надзором Министерства уже десять лет."

    d "Первые три из них мне даже не позволяли выйти за эти ворота без письменного разрешения."

    "Он слегка приподнял бровь."

    d "Ты действительно думаешь, что сейчас сообщишь мне что-нибудь новенькое?"

    hide draco neutral
    show herm  neutral
         

    h "Нет."

    "Гермиона закрыла папку."

    h "Я думаю, что проведу проверку, поставлю подпись и вернусь домой."

    hide herm neutral
    show draco neutral 

    d "Наконец-то у нас появился общий интерес."

    "На несколько секунд между ними повисла тишина."

    "Гермиона снова раскрыла папку."

    h "Тогда, если ты закончил..."

    hide herm neutral
    show draco neutral 

    d "Я только начал."

    hide draco neutral
    show herm  neutral
         

    h "Как я и боялась."

    "Гермиона раскрыла папку и пробежала взглядом по первой странице."

    h "Хорошо. Начнём."

    h "Место постоянного проживания за последний месяц не менялось?"

    hide herm neutral
    show draco neutral 


    d "Ты сейчас находишься в нём."

    hide draco neutral
    show herm  neutral
         

    h "Я запишу это как «нет»."

    "Перо Гермионы быстро скользнуло по пергаменту."

    h "Покидал территорию Великобритании?"
    
    hide herm neutral
    show draco neutral 


    d "Нет."

    hide draco neutral
    show herm  neutral
         

    h "Контакты с лицами, находящимися под надзором Министерства?"

    hide herm neutral
    show draco neutral 


    d "Если не считать тебя — нет."

    hide draco neutral
    show herm  neutral
         

    h "Я не нахожусь под надзором Министерства."

    hide herm neutral
    show draco neutral 


    d "Какая досада."

    hide draco neutral
    show herm  neutral
         

    "Гермиона подняла на него взгляд."

    h "Малфой."

    hide herm neutral
    show draco neutral 


    d "Грейнджер."

    "Несколько секунд они смотрели друг на друга."

    hide draco neutral
    show herm  neutral
         

    "Гермиона первой вернулась к бумагам."

    h "Приобретение, хранение или использование предметов, внесённых в реестр запрещённых магических артефактов?"

    hide herm neutral
    show draco neutral 


    d "Нет."

    hide draco neutral
    show herm  neutral
         

    h "Попытки получить доступ к конфискованному имуществу семьи Малфоев?"

    hide herm neutral
    show draco neutral 


    d "Нет."

    hide draco neutral
    show herm  neutral
         

    h "Незарегистрированные защитные или скрывающие чары на территории поместья?"

    hide herm neutral
    show draco neutral 


    d "Нет."

    hide draco neutral
    show herm  neutral
         

    h "Изменения в защитном контуре Мэнора?"

    hide herm neutral
    show draco neutral 


    d "Только плановые."

    hide draco neutral
    show herm  neutral
         

    h "Они зарегистрированы?"

    hide herm neutral
    show draco neutral 


    d "Уилсон получил документы три недели назад."

    hide draco neutral
    show herm  neutral
         

    "Гермиона нашла соответствующую отметку и поставила последнюю галочку."

    h "Да. Вижу."

    "Она перелистнула страницу, ещё раз проверила записи и закрыла папку."

    h "На этом официальная часть закончена."

    hide herm neutral
    show draco neutral 

    d "Восхитительно."

    "Драко откинулся на спинку кресла."

    hide herm neutral
    show draco neutral 

    d "Должен признать, Грейнджер, твои методы допроса почти заставили меня скучать по Уилсону."

    hide draco neutral
    show herm  neutral
         

    h "Это была проверка, а не допрос."

    hide herm neutral
    show draco neutral 

    d "Разумеется."

    hide draco neutral
    show herm  neutral
         

    "Гермиона уже собиралась убрать папку в сумку, но остановилась."

    "Именно этот вопрос занимал её с того момента, как утром она увидела фамилию Малфоя в списке назначений."

    h "Есть ещё кое-что."

    "Драко посмотрел на неё."

    hide herm neutral
    show draco neutral 

    d "Я почему-то не удивлён."

    hide draco neutral
    show herm  neutral
         

    h "Это не относится к сегодняшней проверке."

    hide herm neutral
    show draco neutral 

    d "А вот теперь мне стало интересно."

    hide draco neutral
    show herm  neutral
         
    stop music fadeout 3.0

    "Гермиона немного помедлила."

    play music "audio/Candlelit Tension.mp3" loop fadein 3.0

    h "Ты помнишь трость своего отца?"

    "Выражение лица Драко едва заметно изменилось."

    hide herm neutral
    show draco neutral 

    d "Довольно трудно забыть вещь, с которой он практически не расставался."

    hide draco neutral
    show herm  neutral
         

    h "Ты знаешь, где она сейчас?"

    hide herm neutral
    show draco neutral 

    d "Нет."

    "Ответ прозвучал слишком быстро."

    hide draco neutral
    show herm  neutral
         

    "Гермиона чуть подалась вперёд."

    h "Совсем ничего?"

    hide herm neutral
    show draco neutral 

    d "Кажется, слово «нет» не изменило своего значения за те годы, что мы не общались."

    hide draco neutral
    show herm  neutral
         

    h "После смерти Люциуса трость не нашли."

    hide herm neutral
    show draco neutral 

    d "Я знаю."

    hide draco neutral
    show herm  neutral
         

    h "Она отсутствует в перечне предметов, изъятых из Мэнора. Её нет в хранилищах Министерства. Нет среди вещей, оставленных семье."

    h "Фактически она исчезла в ночь смерти твоего отца."

    hide herm neutral
    show draco neutral 

    "Драко некоторое время молчал."

    d "И ты решила, что я прячу её здесь последние десять лет?"

    hide draco neutral
    show herm  neutral
         

    h "Я пока ничего не решила."

    hide herm neutral
    show draco neutral 

    d "Но подозреваешь."

    hide draco neutral
    show herm  neutral
         

    h "Я занимаюсь тёмными артефактами, Малфой. Подозревать — часть моей работы."

    hide herm neutral
    show draco neutral 

    d "Удобная профессия."

    hide draco neutral
    show herm  neutral
         

    h "Особенно когда люди отвечают на вопросы."

    hide herm neutral
    show draco neutral 

    "На этот раз в его взгляде уже не было прежней ленивой насмешки."

    d "Тогда запиши ещё один ответ."

    d "Когда умер мой отец, меня здесь не было."

    hide draco neutral
    show herm  neutral
         

    h "Я знаю."

    hide herm neutral
    show draco neutral 

    d "Нет, Грейнджер. Ты знаешь это из дела."

    "Он выпрямился в кресле."

    d "А я в это время сидел в камере Министерства и по несколько часов в день объяснял вашим людям," 
    "что делал каждый месяц последних трёх лет своей жизни."

    "Гермиона ничего не ответила."

    hide herm neutral
    show draco neutral 

    d "Я не видел отца перед смертью. Я не присутствовал при обыске. И я не имел возможности спрятать от вас его вещи."

    hide draco neutral
    show herm  neutral
         

    h "Но после возвращения в Мэнор ты мог обнаружить трость."

    hide herm neutral
    show draco neutral 

    d "Мог."

    hide draco neutral
    show herm  neutral
         

    h "И?"

    hide herm neutral
    show draco neutral 

    d "Не обнаружил."

    hide draco neutral
    show herm  neutral
         

    h "Ты её искал?"

    hide herm neutral
    show draco neutral 

    "Драко чуть нахмурился."

    d "Нет."

    hide draco neutral
    show herm  neutral
         

    h "Почему?"

    hide herm neutral
    show draco neutral 

    d "Потому что, когда я вернулся домой, половины вещей моей семьи здесь уже не было."

    d "Министерство провело в этом доме несколько дней. Авроры вскрывали хранилища, проверяли комнаты и вывозили всё," 
    "что считали хоть сколько-нибудь подозрительным."

    hide draco neutral
    show herm  neutral
         

    h "Все изъятые предметы должны были попасть в реестр."

    hide herm neutral
    show draco neutral 

    d "Должны были."

    "Он выделил последнее слово так, что Гермиона сразу уловила смысл."

    hide draco neutral
    show herm  neutral
         

    h "Ты думаешь, её забрало Министерство."

    hide herm neutral
    show draco neutral 

    d "Я думаю, что последними людьми, имевшими полный доступ к вещам моего отца, были ваши люди."

    hide draco neutral
    show herm  neutral
         

    h "И Министерство десять лет скрывает одну трость?"

    hide herm neutral
    show draco neutral 

    d "Не льсти своему ведомству."

    d "Чтобы потерять вещь, вовсе не обязательно устраивать заговор."

    hide draco neutral
    show herm neutral 
         

    "Гермиона нахмурилась."

    h "Это не просто трость."

    hide herm neutral
    show draco neutral 

    d "Я в курсе."

    hide draco neutral
    show herm  neutral
         

    h "После войны специалисты обнаружили на ней следы тёмной магии."
    
    hide herm neutral
    show draco neutral 
        
    "Драко едва заметно усмехнулся."

    
    d "На половине вещей моего отца можно было обнаружить следы тёмной магии."

    hide draco neutral
    show herm  neutral
         

    h "Именно поэтому меня интересует, где она." 

    hide herm neutral
    show draco neutral 

    d "А меня, Грейнджер, гораздо больше интересует другое."

    hide draco neutral
    show herm  neutral
         

    h "Что?"
    
    hide herm neutral
    show draco neutral 

    "Он посмотрел ей прямо в глаза."

    

    d "Почему Министерство потеряло вещь моего отца десять лет назад, а сегодня ты сидишь в моём доме и спрашиваешь, куда её дел я."

    "На несколько мгновений в комнате стало совсем тихо."

    "За высокими окнами сверкнула молния."

    "Через несколько секунд над поместьем тяжело прокатился гром."

    "Драко перевёл взгляд на окна."

    "На этот раз привычная насмешка исчезла с его лица."

    d "Мне не нравится эта гроза."

    stop music fadeout 3.0


    jump scene_03_storm