label test:

    scene manor hall2
    
    show herm neutral
    show draco neutral2
    "show herm neutral show draco neutral2"
    
    show herm coat
    show draco neutral rain2
    "show herm coat show draco coat"

   
    show herm ser 
    show draco neutral2 
    "show herm ser show draco neutral2"


    show draco hot3
    show herm hot
    "show herm hot show draco hot3"

    show herm hot2
    show draco naked
    "show herm hot2 show draco naked"


    show herm sad3
    show draco neutral2 
    "show herm sad3"

    show herm wine
    show draco whiskey
    "show herm wine show draco whiskey"

    show herm letter
    show draco letter
    "show herm letter show draco letter"