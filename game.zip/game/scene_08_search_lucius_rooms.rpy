label scene_08_search_lucius_rooms:

    scene manor hallway1
    with Dissolve(1.5)

    play music "audio/Tick Tock, Darling.mp3" loop fadein 3.0


    "Гермиона и Драко вышли из гостиной и направились вглубь Мэнора."

    "Чем дальше они уходили от жилых комнат, тем тише становилось вокруг."

    "Драко шёл впереди, словно мог пройти по этим коридорам с закрытыми глазами."

    "Несколько минут они молчали." 
    
    show herm neutral at left

    "Гермиона посмотрела на его спину."

    h "Знаешь, Малфой..."

    show draco neutral at right

    hide herm neutral

    d "Звучит уже угрожающе."

    hide draco neutral2

    show herm neutral at left

    h "Ты ведь совсем недавно спрашивал, что я делаю здесь в пятницу вечером."

    hide herm neutral

    show draco neutral at right

    d "И?"

    hide draco neutral2

    show herm neutral at left

    h "А что здесь делаешь ты?"

    show draco neutral at right

    hide herm neutral

    d "Я здесь живу, Грейнджер."

    hide draco neutral2

    show herm neutral at left

    h "Очень смешно."

    "Гермиона закатила глаза."

    h "Я серьёзно."

    h "Пятница. Вечер."

    h "Ты молод, богат..."

    "Она демонстративно оглядела его с головы до ног."

    h "При определённом освещении даже симпатичен."

    hide herm neutral

    show draco neutral at right

    d "При определённом?"

    hide draco neutral2

    show herm neutral at left

    h "Не отвлекайся."

    hide herm neutral

    show draco neutral at right

    d "Нет-нет. Теперь мне интересно, какое именно освещение требуется."

    hide draco neutral2

    show herm neutral at left

    h "Малфой."

    hide herm neutral

    show draco neutral at right

    d "Грейнджер."

    hide draco neutral2

    show herm neutral at left

    "Гермиона не выдержала и усмехнулась."

    h "Почему ты сидишь дома?"

    "На этот раз он ответил не сразу."

    show draco neutral at right

    hide herm neutral

    d "Полагаю, война несколько сузила круг моих социальных возможностей."

    "Он произнёс это легко, почти небрежно."

    hide draco neutral2

    show herm neutral at left

    h "У тебя ведь остались друзья."

    hide herm neutral

    show draco neutral at right

    d "Тео. Блейз."

    d "Ещё несколько человек, которых при большом желании можно записать в знакомые."

    hide draco neutral2

    show herm neutral at left

    h "И они тоже проводят пятничные вечера в фамильных склепах?"

    show draco neutral at right

    hide herm neutral

    show draco neutral at right

    d "К сожалению, нет."

    d "Блейз каким-то образом сохранил удивительную способность появляться там, где есть алкоголь, красивые женщины и отсутствие здравого смысла."

    hide draco neutral2

    show herm neutral at left

    h "Звучит как талант."

    hide herm neutral

    show draco neutral at right

    d "Он именно так это и называет."

    "Они свернули в следующий коридор."

    d "А Тео женат."

    hide draco neutral2

    show herm neutral at left

    h "И?"

    hide herm neutral

    show draco neutral at right

    d "И существует определённый момент в жизни женатого мужчины, когда он начинает приглашать холостого друга на ужин."

    hide draco neutral2 

    show herm neutral at left

    h "Разве это плохо?"

    hide herm neutral

    show draco neutral at right

    d "Нет."

    d "Плохо, когда понимаешь, что тебя приглашают уже не потому, что хотят видеть."

    "Он выдержал короткую паузу."

    d "А потому что им тебя жалко."

    hide draco neutral2

    show herm neutral at left

    "Гермиона рассмеялась."

    h "О, Мерлин."

    h "Неужели Нотт дошёл до стадии «Драко, приходи в воскресенье, мы будем очень рады»?"

    hide herm neutral

    show draco neutral at right

    d "Хуже."

    show draco neutral at right

    d "Его жена начала уточнять, что я могу привести кого-нибудь с собой."

    hide draco neutral2

    show herm neutral at left

    "Гермиона снова рассмеялась."

    h "Нет."

    hide herm neutral

    show draco neutral at right

    d "Да."

    hide draco neutral2

    show herm neutral at left

    h "Это ужасно."

    hide herm neutral

    show draco neutral at right

    d "Благодарю за сочувствие."

    hide draco neutral2

    show herm neutral at left

    h "Я совершенно тебе не сочувствую."

    hide herm neutral

    show draco neutral at right

    d "Я заметил."

    hide draco neutral2

    "Улыбка ещё оставалась на губах Гермионы."

    "А потом она посмотрела на него."

    show draco smile2 at right

    "Он тоже улыбался."

    "Только теперь стало очевидно, что шутка была смешной лишь отчасти."

    hide draco neutral2

    show herm neutral at left

    "После войны Гермионе почти не приходилось задумываться о том, как выглядит жизнь Малфоя за пределами редких встреч и газетных заметок."

    "Для неё война закончилась."

    "Для него, похоже, некоторые её последствия просто стали повседневностью."

    "Гермиона отвела взгляд."

    h "Малфой..."

    hide herm neutral

    show draco neutral at right

    d "Не надо, Грейнджер."

    "Тон у него оставался лёгким."

    show draco neutral at right

    d "Если ты сейчас начнёшь меня жалеть, я буду вынужден отправить Тео письмо с извинениями."

    hide draco neutral2

    show herm neutral at left

    "Гермиона фыркнула."

    h "Не мечтай."

    hide herm neutral

    show draco neutral at right

    d "Вот и прекрасно."

    stop music fadeout 3.0

    play music "audio/Sombra Aristocratica.mp3" loop fadein 3.0

    hide herm
    hide draco

    "Они остановились перед тяжёлой дверью в самом конце коридора."

    "Здесь Мэнор казался другим."

    "Старше."

    "Тише."

    show draco neutral at right
    show herm neutral at left

    "Драко положил ладонь на потемневшую дверную ручку и придержал дверь, пропуская Гермиону вперёд."

    "Проход оказался уже, чем ожидалось."

    "Гермиона прошла, задев Драко плечом"

    scene lucius room
    with dissolve

    "И только оказавшись внутри, остановилась."

    "До этого момента покои Люциуса существовали для неё исключительно как место, которое следовало осмотреть."

    "Последнее место, где он провёл ночь."

    "Последнее место, где видели его трость."

    "Потенциальный источник улик."

    "Но сейчас Гермиона вдруг с неприятной ясностью осознала, что стоит посреди спальни умершего человека."

    "Отца Драко."

    "Комната всё ещё хранила слишком много личного."

    "Книги на полках. Письменный стол. Кресло у камина."

    "Даже спустя десять лет это место не казалось заброшенным."

    show herm neutral 

    "Гермиона немного неловко оглянулась на Драко."

    h "Ты уверен, что не против?"

    hide herm neutral

    show draco neutral2 

    d "Грейнджер."

    d "Ты пять минут назад заявила, что собираешься обыскать покои моего отца."

    d "Мы прошли сюда через половину Мэнора."

    d "Немного поздно обнаруживать в себе деликатность."

    hide draco neutral2

    show herm neutral 

    h "Я просто спрашиваю."

    hide herm neutral

    show draco smile2 

    d "Валяй."

    d "Ищи, ищейка."

    hide draco smile2

    show herm neutral 

    h "Ищейка?"

    hide herm neutral

    show draco smile2 

    d "Ты ведь за этим сюда пришла."

    d "Не разочаровывай меня."

    hide draco smile2

    show herm neutral 

    "Гермиона прищурилась."

    h "Я припомню тебе это, когда что-нибудь найду."

    hide herm neutral

    show draco neutral2 

    d "С нетерпением жду."

    hide draco neutral2

    "Гермиона принялась осматривать комнату."

    "Сначала — просто глазами."

    "Она медленно прошла вдоль книжных полок."

    "Задержалась у письменного стола."

    "Осмотрела камин, шкафы, прикроватную тумбу."

    "Комната была большой, но не показной."

    "Скорее тяжёлой."

    "Слишком тёмной, слишком строгой и слишком похожей на самого Люциуса Малфоя, каким Гермиона его помнила."

    show herm neutral 

    h "Авроры всё это осматривали?"

    hide herm neutral

    show draco neutral2 

    d "Неоднократно."

    hide draco neutral2

    show herm neutral 

    h "Тогда обычным поиском мы ничего не найдём."

    "Она достала волшебную палочку."

    hide herm neutral

    show draco neutral2 

    "Драко прислонился плечом к краю книжного шкафа."

    d "И что ты собираешься делать?"

    hide draco neutral2

    show herm neutral 

    $runi = True

    "Вместо ответа Гермиона подняла палочку."

    "Её кончик вспыхнул мягким золотистым светом."

    "Гермиона медленно провела палочкой перед собой."

    "В воздухе одна за другой начали появляться тонкие светящиеся руны."

    "Она произнесла несколько тихих слов."

    "Руны дрогнули."

    "Затем разошлись по комнате."

    "Одни скользнули вдоль стен."

    "Другие исчезли между книжными полками."

    "Несколько золотых линий растеклись по поверхности письменного стола."

    hide herm neutral

    show draco neutral2 

    "Драко наблюдал за ней уже без прежней насмешки."

    d "Не помню такого заклинания."

    hide draco neutral2

    show herm neutral 

    h "И не должен."

    hide herm neutral

    show draco neutral2 

    d "Вот как?"

    d "Я, конечно, допускаю, что за десять лет успел забыть половину школьной программы."

    d "Но не настолько."

    d "К тому же последние годы у меня было довольно много свободного времени."

    "Он кивнул в сторону книжных полок."

    d "Когда большую часть развлечений тебе запрещает Министерство, библиотека неожиданно становится очень привлекательным местом."

    d "Я перечитал почти всё, что здесь есть."

    d "И этого заклинания не видел."

    hide draco neutral2

    show herm neutral 

    "На губах Гермионы появилась едва заметная довольная улыбка."

    h "Потому что его нет в книгах."

    hide herm neutral

    show draco neutral2 

    d "Грейнджер."

    d "Ты сейчас собираешься сказать, что сама его придумала?"

    hide draco neutral2

    show herm neutral 

    h "Не совсем."

    h "Основа старая."

    h "Заклинания поиска магических полостей, несколько диагностических чар и руническая схема обнаружения искажений пространства."

    hide herm neutral

    show draco neutral2 

    d "Разумеется."

    hide draco neutral2

    show herm neutral 

    h "Но вместе они работали плохо."

    h "Артефакты часто прячут в местах, защищённых сразу несколькими слоями чар."

    h "Обычные поисковые заклинания находят магию."

    h "А мне нужно было находить то, что эту магию пытается скрыть."

    "Она слегка повернула палочку."

    "Одна из рун изменила направление."

    h "Поэтому я доработала схему."

    hide herm neutral

    show draco neutral2 

    "Несколько секунд Драко молчал."

    d "Ты разработала собственное заклинание для поиска тайников?"

    hide draco neutral2

    show herm neutral 

    h "Для поиска скрытых магических пространств."

    hide herm neutral

    show draco smile2 

    d "Прошу прощения."

    d "Не хотел оскорбить научную терминологию."

    hide draco smile2

    show herm neutral 

    h "Можешь смеяться."

    h "Эта штука нашла семь нелегальных хранилищ за последние два года."

    hide herm neutral

    show draco neutral2 

    d "Я не смеюсь."

    "И действительно."

    "В его голосе больше не было насмешки."

    "Он смотрел на светящиеся руны с неподдельным интересом."

    d "Это впечатляет."

    hide draco neutral2

    show herm neutral 

    "Гермиона на мгновение сбилась."

    "Комплимент от Малфоя почему-то оказался приятнее, чем следовало."

    h "Спасибо."

    "Она снова сосредоточилась на заклинании."

    "Большинство рун постепенно погасло."

    "Но одна продолжала светиться."

    "У письменного стола."

    "Гермиона подошла ближе."

    h "Вот."

    hide herm neutral

    show draco neutral2 

    d "Что?"

    hide draco neutral2

    show herm neutral 

    h "Здесь что-то есть."

    "Она провела палочкой вдоль деревянной панели."

    "На мгновение ничего не произошло."

    "Затем раздался тихий щелчок."

    "Из боковой стенки стола выдвинулся узкий потайной ящик."

    hide herm neutral

    show draco neutral2 

    "Драко выпрямился."

    d "Любопытно."

    hide draco neutral2

    show herm neutral 

    "Гермиона осторожно заглянула внутрь."

    "Трости там не было."

    "Вообще никаких тёмных артефактов."

    "Только небольшая колдография."

    "Гермиона взяла её в руки."

    hide herm neutral

    show photo malfoys

    "На снимке стояли трое."

    "Люциус."

    "Нарцисса."

    "И совсем юный Драко между ними."

    "Фигуры на колдографии едва заметно двигались."

    "Нарцисса что-то сказала сыну."

    "Драко повернул голову к матери."

    "А Люциус положил ладонь ему на плечо."

    "Гермиона смотрела на колдографию немного дольше, чем собиралась."

    hide photo Malfoys

    "Затем подняла глаза."

    hide herm neutral

    show draco neutral2 

    "Драко больше не смотрел на неё."

    "Он смотрел на фотографию."

    "И выражение его лица едва заметно изменилось."

    "Совсем немного."

    "Но Гермиона заметила."

    menu:

        "Тактично промолчать":

            "Гермиона ничего не сказала."

            "Некоторые вещи не становились легче от правильно подобранных слов."

            "Она осторожно положила фотографию обратно в потайной ящик."

            hide herm neutral

            show draco neutral2:
                xalign 0.72
                yalign 1.0

            "Драко коротко взглянул на неё."

            d "Спасибо."

            hide draco neutral2

            show herm neutral:
                xalign 0.30
                yalign 1.0

            "Гермиона лишь кивнула."


        "Посочувствовать":

            $ draco_warmth += 1

            "Гермиона ещё несколько секунд смотрела на фотографию."

            h "Мне жаль."

            hide herm neutral

            show draco neutral2:
                xalign 0.72
                yalign 1.0

            d "Что именно?"

            hide draco neutral2

            show herm neutral:
                xalign 0.30
                yalign 1.0

            h "То, что произошло с вашей семьёй."

            h "И то, что для тебя это до сих пор не закончилось."

            "Драко ничего не ответил."

            h "Мы привыкли говорить о войне так, будто однажды она просто закончилась."

            h "Была битва. Мы победили. Прошло десять лет."

            h "Но ты всё это время продолжаешь жить с её последствиями."

            h "Надзор. Проверки. Этот дом."

            h "Даже пятничные вечера, которые ты проводишь здесь не совсем потому, что сам так выбрал."

            hide herm neutral

            show draco neutral2:
                xalign 0.72
                yalign 1.0

            "Драко долго смотрел на неё."

            d "Осторожнее, Грейнджер."

            d "Ещё немного — и я решу, что ты мне сочувствуешь."

            hide draco neutral2

            show herm neutral:
                xalign 0.30
                yalign 1.0

            h "Возможно, сегодня можешь себе позволить."

            hide herm neutral

            show draco neutral2:
                xalign 0.72
                yalign 1.0

            "На этот раз он не нашёлся с ответом сразу."

            d "Только сегодня?"

            hide draco neutral2

            show herm neutral:
                xalign 0.30
                yalign 1.0

            "Гермиона почувствовала, как уголок её губ дрогнул."

            h "Не наглей, Малфой."


        "Разозлиться":

            $ draco_tension += 1

            "Гермиона нахмурилась."

            h "Знаешь, что самое мерзкое?"

            hide herm neutral

            show draco neutral2:
                xalign 0.72
                yalign 1.0

            d "Предчувствую, что сейчас узнаю."

            hide draco neutral2

            show herm neutral:
                xalign 0.30
                yalign 1.0

            h "Я ненавижу Волан-де-Морта."

            hide herm neutral

            show draco neutral2:
                xalign 0.72
                yalign 1.0

            d "Смелое заявление."

            hide draco neutral2

            show herm neutral:
                xalign 0.30
                yalign 1.0

            h "Малфой, помолчи."

            h "Он пришёл в ваш дом."

            h "Использовал твоего отца. Запугивал твою мать."

            h "Заставил шестнадцатилетнего мальчишку выполнять приказ, за который тот мог погибнуть."

            h "Он разрушил вашу семью практически так же методично, как разрушал семьи своих противников."

            "Гермиона раздражённо выдохнула."

            h "А потом он умер."

            h "И вместо того чтобы дать тебе наконец жить собственной жизнью, Министерство решило продолжить за него."

            hide herm neutral

            show draco neutral2:
                xalign 0.72
                yalign 1.0

            "Драко медленно поднял бровь."

            d "Ты сейчас сравнила Министерство магии с Тёмным Лордом?"

            hide draco neutral2

            show herm neutral:
                xalign 0.30
                yalign 1.0

            h "Нет."

            h "Я сказала, что если цель надзора — помочь человеку вернуться к нормальной жизни, то десять лет изоляции — чертовски странный способ это сделать."

            h "Тебе двадцать семь."

            h "Ты не должен сидеть в этом доме и отчитываться перед Министерством до конца жизни за решения, которые принимал подростком."

            hide herm neutral

            show draco neutral2:
                xalign 0.72
                yalign 1.0

            "Несколько секунд Драко просто смотрел на неё."

            show draco smile2:
                xalign 0.72
                yalign 1.0

            d "Грейнджер."

            d "Ты сейчас защищаешь меня?"

            hide draco smile2

            show herm neutral:
                xalign 0.30
                yalign 1.0

            h "Я защищаю здравый смысл."

            hide herm neutral

            show draco smile2:
                xalign 0.72
                yalign 1.0

            d "Разумеется."

            d "А я уже начал волноваться."

            hide draco smile2

            show herm neutral:
                xalign 0.30
                yalign 1.0

            h "Продолжишь — передумаю."

            hide herm neutral

            show draco smile2:
                xalign 0.72
                yalign 1.0

            d "Вот теперь я узнаю Грейнджер."   

        "Гермиона ещё раз медленно оглядела комнату."

    hide draco smile2    

    "Никаких других скрытых пространств."

    "Никаких следов тёмной магии."

    "И, разумеется, никакой трости."

    h "Похоже, здесь больше ничего нет."

    hide herm neutral

    show draco neutral2 

    d "Надеюсь, это означает, что ты закончила разбирать вещи моего отца."

    hide draco neutral2

    show herm neutral 

    h "На сегодня."

    hide herm neutral

    show draco smile2 

    d "Как обнадёживающе."

    hide draco smile2

    "Они вышли в коридор."

    show herm neutral 

    "Гермиона уже собиралась спросить, куда идти дальше, когда её взгляд остановился на стене напротив."

    "Там висел старый портрет."

    "Мужчина в тяжёлой раме сидел в кресле, недовольно наблюдая за ними из-под густых бровей."

    "Гермиона посмотрела на дверь спальни."

    "Потом снова на портрет."

    h "Малфой."

    hide herm neutral

    show draco neutral2 

    d "Что?"

    hide draco neutral2

    show herm neutral 

    h "Он всегда здесь висел?"

    hide herm neutral

    show draco neutral2 

    "Драко проследил за её взглядом."

    d "К сожалению."

    hide draco neutral2

    show herm neutral 

    h "Он видит дверь спальни Люциуса."

    hide herm neutral

    show draco neutral2 

    "Драко замолчал."

    "Затем медленно повернул голову к портрету."

    d "Да."

    hide draco neutral2

    show herm neutral 

    h "Значит, он мог видеть, кто входил и выходил той ночью."

    hide herm neutral

    show draco neutral2 

    d "Мог."

    hide draco neutral2

    show herm neutral 

    h "Министерство его опрашивало?"

    hide herm neutral

    show draco smile2 

    d "Пыталось."

    hide draco smile2

    show herm neutral 

    h "И?"

    hide herm neutral

    show draco neutral2 

    d "Он не любит Министерство."

    d "И людей."

    "Драко сделал паузу."

    d "Вообще почти никого."

    hide draco neutral2

    show herm neutral 

    h "Но с тобой он поговорит?"

    hide herm neutral

    show draco smile2 

    d "Вероятно."

    d "Я всё-таки Малфой."

    hide draco smile2

    show herm neutral 

    h "Удивительно полезное качество."

    hide herm neutral

    show draco smile2 

    d "Иногда."

    d "Но предупреждаю."

    d "Он противный."

    hide draco smile2

    show herm neutral 

    h "Насколько?"

    hide herm neutral

    show draco neutral2 

    d "Настолько, что смерть почти не улучшила его характер."

    stop music fadeout 3.0


    hide draco neutral2

    jump scene_09_portrait
     