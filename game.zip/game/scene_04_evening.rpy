label scene_04_evening:

    scene manor fire
    with Dissolve(1.5)

    # Гермиона только что поняла, что покинуть Мэнор до окончания шторма не сможет.

    show draco neutral 


    "Драко ещё несколько секунд смотрел на бесполезно горящий камин."

    play music "audio/Dry British Comedy.mp3" loop fadein 3.0

    d "Полагаю, придётся признать очевидное."

    hide draco neutral

    show herm neutral 

    h "Я застряла здесь."

    hide herm neutral

    show draco neutral 

    d "Я собирался сказать, что тебе придётся воспользоваться моим гостеприимством."

    d "Но твоя версия звучит драматичнее."

    hide draco neutral

    show herm neutral 

    h "Ты удивительно доволен сложившейся ситуацией."

    hide herm neutral

    show draco neutral 

    d "Грейнджер, пятничный вечер, гроза и сотрудник Министерства, который не может покинуть мой дом."

    d "Я просто пытаюсь найти положительные стороны."

    hide draco neutral

    show herm neutral 

    h "Разумеется."

    hide herm neutral

    show draco neutral 

    "Драко бросил короткий взгляд в сторону лестницы."

    d "Я попрошу домовиков приготовить тебе гостевую спальню."

    d "Там найдётся всё необходимое."

    "Он сделал небольшую паузу."

    d "Или..."

    hide draco neutral

    show herm neutral 

    h "Или?"

    hide herm neutral

    show draco neutral 

    d "Можешь остаться."

    d "Всё-таки пятница."

    d "У меня есть вино."

    hide draco neutral

    show herm ser 

    "Гермиона посмотрела на него с подозрением."

    h "Ты предлагаешь выпить сотруднику Министерства во время проверки?"

    hide herm ser

    show draco neutral 

    d "Проверка закончилась."

    d "Теперь я предлагаю выпить женщине, которая застряла в моём доме."

    hide draco neutral

    show draco smile2 

    "Уголок его губ едва заметно приподнялся."

    d "Разница принципиальная."


    menu:

        "Остаться с Драко":

            $ draco_warmth += 1

            hide draco smile2

            show herm neutral 

            h "Один бокал."

            hide herm neutral

            show draco neutral 

            d "Разумеется."

            d "Я бы ни за что не стал пользоваться твоим безвыходным положением."

            hide draco neutral

            show herm neutral 

            h "Почему именно эта фраза заставляет меня беспокоиться ещё больше?"

            hide herm neutral

            show draco neutral 

            d "Понятия не имею."

            stop music fadeout 3.0

            jump wine_evening


        "Уйти в спальню":     

        

            hide draco smile2

            show herm neutral 

            h "Спасибо, но я, пожалуй, воспользуюсь спальней."

            hide herm neutral

            show draco neutral 

            d "Как пожелаешь."

            "Он не стал ни уговаривать её, ни отпускать очередную колкость."

            d "Домовик проводит тебя."

            stop music fadeout 3.0

            jump guest_room


label guest_room:

    play music "audio/Candlelit Mystery.mp3" loop fadein 3.0

    scene bedroom
    with Dissolve(1.5)

    hide draco neutral

    show herm neutral 

    "Спальня оказалась гораздо уютнее, чем Гермиона ожидала."

    "И совершенно бесполезной."

    "Она лежала в темноте и слушала, как дождь барабанит по окнам."

    "Спать не хотелось."

    "Вернее, тело отчаянно требовало сна."

    "Но мозг категорически отказывался сотрудничать."

    "Трость Люциуса Малфоя."

    "Десять лет."

    "Десять лет она числилась пропавшей."

    "И всё это время никто не смог установить даже момент её исчезновения."

    "Гермиона перевернулась на другой бок."

    "Прошло ещё несколько минут."

    h "Ох, да чтоб тебя."

    "Она отбросила одеяло."

    "Если уж ей всё равно не спалось, можно было хотя бы задать Малфою ещё несколько вопросов."

    stop music fadeout 3.0


    jump wine_evening


label wine_evening:

    # Возвращаемся в гостиную.
    # Здесь можно поставить фон комнаты с камином.

    play music "audio/Calor de la Noche.mp3" loop fadein 3.0

    hide herm neutral

    scene malfoy hall
    with Dissolve(1.5)

    show draco neutral 

    "Когда Гермиона оказалась в гостиной, Драко уже стоял у небольшого столика с напитками."

    "Для неё он налил вино."

    "Себе — немного виски."

    "Драко протянул ей бокал."

    "Их пальцы на мгновение соприкоснулись."

    hide draco whiskey

    show herm wine 

    "Гермиона приняла протянутый бокал."

    h "Спасибо."

    hide herm 
    
    scene talk wine

    " "
    scene malfoy hall

    show draco whiskey 

    d "Не благодари раньше времени."

    d "Возможно, к утру ты обнаружишь, что Министерство внесло алкоголь Малфоев в список запрещённых артефактов."

    hide draco whiskey

    show herm wine 

    h "Если он настолько плох, я лично займусь оформлением."

    "Она сделала небольшой глоток."

    "Вино оказалось хорошим."

    "Раздражающе хорошим."

    hide herm wine

    show draco whiskey 

    d "Ну?"

    hide draco whiskey

    show herm wine 

    h "Терпимо."

    hide herm wine

    show draco whiskey 

    d "Какая высокая оценка."

    "Драко сделал глоток виски."

    "Несколько секунд они молчали."

    "За окнами продолжал шуметь дождь."

    d "А Уизли-младший не будет возражать?"

    hide draco whiskey

    show herm wine 

    h "Против чего?"

    hide herm wine

    show draco whiskey 

    d "Против того, что ты проводишь ночь в Мэноре."

    "Он слегка качнул бокалом."

    d "В компании Малфоя."

    hide draco whiskey

    show herm wine 

    "Гермиона посмотрела на него поверх своего бокала."

    h "Рон уже год не имеет никакого отношения к тому, где я провожу ночи."

    hide herm wine

    show draco whiskey 

    "Драко замер всего на мгновение."

    d "Ясно."

    hide draco whiskey

    show herm wine 

    h "Ты прекрасно об этом знал."

    hide herm wine

    show draco whiskey 

    d "Я читаю газеты."

    hide draco whiskey

    show herm wine  

    h "И решил всё равно спросить?"

    hide herm wine

    show draco whiskey 

    d "Газеты часто врут."

    "Он сделал ещё один глоток."

    d "Особенно когда пишут о людях, которых я знаю."

    "Гермиона чуть приподняла бровь."

    hide draco whiskey

    show herm wine 

    h "Не знала, что ты относишь меня к людям, которых знаешь."

    hide herm wine

    show draco whiskey 

    "В его взгляде мелькнуло что-то похожее на улыбку."

    d "Я провёл рядом с тобой шесть лет."

    d "Поверь, некоторые особенности характера забыть невозможно."

    hide draco whiskey

    show herm wine 

    h "Я даже не стану спрашивать, какие."

    hide herm wine

    show draco whiskey 

    d "Разумное решение."

    "Разговор снова ненадолго стих."

    "Странно, но молчание уже не казалось таким неловким."

    "Драко медленно повертел стакан в руке."

    d "Тогда объясни мне кое-что."

    hide draco whiskey

    show herm wine 

    h "Что?"

    hide herm wine

    show draco whiskey 

    d "Что ты вообще делала на работе в пятницу вечером?"

    hide draco whiskey

    show herm wine 

    h "Работала."

    hide herm wine

    show draco whiskey 

    d "Я догадался."

    d "Я скорее спрашиваю, почему."

    d "У тебя ведь всё ещё есть друзья."

    hide draco whiskey

    show herm wine 

    h "Спасибо за беспокойство о моей социальной жизни."

    hide herm wine

    show draco whiskey 

    d "Не беспокойство."

    "Он посмотрел на неё поверх стакана."

    d "Любопытство."


    menu:

        "Съязвить":

            $ draco_tension += 1

            hide draco whiskey

            show herm wine 

            h "Удивительно, Малфой."

            h "Всего один бокал, а ты уже решил, что получил доступ к моей личной жизни."

            hide herm wine

            show draco whiskey 

            d "Не получил."

            "Он спокойно отпил виски."

            d "Но, как видишь, попытался."

            hide draco whiskey

            show herm wine 

            "Гермиона невольно усмехнулась."

            h "Попытка не засчитана."

            jump after_personal_talk


        "Ответить нейтрально":

            hide draco whiskey

            show herm wine 

            h "Просто так получилось."

            h "Уилсон заболел, кому-то нужно было его заменить."

            hide herm wine

            show draco whiskey 

            d "И этим кем-то, разумеется, оказалась ты."

            hide draco whiskey

            show herm wine 

            h "Разумеется."

            jump after_personal_talk


        "Рассказать правду":

            $ draco_warmth += 1

            hide draco whiskey

            show herm wine 

            "Гермиона уже собиралась отделаться привычным ответом."

            "Но почему-то передумала."

            h "Гарри и Джинни теперь часто проводят выходные в Норе."

            h "У них двое детей. Семейные ужины, воскресные завтраки... всё такое."

            "Она провела пальцем по краю бокала."

            h "Раньше я тоже постоянно там бывала."

            h "Но после развода с Роном всё стало немного..."

            "Она поискала подходящее слово."

            h "Неловко."

            h "Молли всегда говорит, что для меня ничего не изменилось."

            h "И я знаю, что она действительно так думает."

            h "Но изменилось."

            "Гермиона ненадолго замолчала."

            h "Теперь, когда они все собираются вместе, я иногда чувствую себя там лишней."

            hide herm wine

            show draco whiskey 

            "Драко не ответил сразу."

            "И, к удивлению Гермионы, не пошутил."

            d "Поэтому ты работаешь."

            hide draco whiskey

            show herm wine 

            h "Поэтому я часто соглашаюсь работать."

            "Она чуть улыбнулась."

            h "Это проще."

            hide herm wine

            show draco whiskey 

            d "Понимаю."

            hide draco whiskey

            show herm wine 

            "Гермиона внимательно посмотрела на него."

            h "Правда?"

            hide herm wine

            show draco whiskey 

            "Он чуть усмехнулся, но на этот раз без привычной насмешки."

            d "Не настолько невероятно, как тебе кажется."

            jump after_personal_talk


label after_personal_talk:

    "Где-то в глубине дома старые часы отбили очередной час."

    "Гермиона посмотрела на вино в своём бокале."

    "Разговор незаметно ушёл слишком далеко от причины, по которой она вообще оказалась в Мэноре."

    "И мысль, которая не давала ей покоя ещё наверху, вернулась."

    hide draco whiskey

    show herm wine 

    h "Малфой."

    hide herm wine

    show draco whiskey 

    d "М-м?"

    hide draco whiskey

    show herm wine 

    h "Я хочу ещё раз спросить тебя об отце."

    hide herm wine

    show draco whiskey 

    "Драко медленно опустил стакан."

    "Лёгкость, появившаяся в разговоре несколько минут назад, исчезла."

    d "Я думал, с официальной частью мы закончили."

    hide draco whiskey

    show herm wine 

    h "Закончили."

    h "Это уже не официальная часть."

    "Гермиона немного помедлила."

    h "Что ты знаешь о последних часах жизни Люциуса?"

    stop music fadeout 3.0


    jump scene_05_lucius_argument