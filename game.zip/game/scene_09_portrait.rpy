label scene_09_portrait:

    scene manor hallway2
    with dissolve

    play music "audio/Suspended Shadows.mp3" loop fadein 3.0


    show herm neutral 

    "Гермиона остановилась перед старым портретом."

    "Мужчина в тяжёлой позолоченной раме окинул её долгим, полным неприязни, взглядом."

    "Затем перевёл глаза на Драко."

    hide herm neutral

    show portrait:
        xalign 0.5
        yalign 0.3

    "Портрет презрительно поджал губы."

    p "Наконец-то."

    p "Я уже начал думать, что ты так и будешь водить эту грязнокровку по семейным покоям."

    hide portrait

    show draco neutral2 

    "Лицо Драко мгновенно изменилось."

    d "Ещё раз назовёшь её так — и остаток вечера проведёшь лицом к стене."

    hide draco neutral2

    show portrait:
        xalign 0.5
        yalign 0.3

    "На портрете воцарилось оскорблённое молчание."

    hide portrait

    show draco neutral2 

    d "Мы поняли друг друга?"

    show portrait:
        xalign 0.5
        yalign 0.3

    hide draco neutral2

    p "У нынешнего поколения Малфоев совершенно не осталось уважения к предкам."

    hide portrait

    show draco neutral2 


    d "Переживу."

    d "Мне нужно знать, что происходило здесь в ночь смерти отца."

    show portrait:
        xalign 0.5
        yalign 0.3

    hide draco neutral2

    p "Прошло десять лет."

    hide portrait

    show draco neutral2 

    d "А ты всё это время висел напротив его двери."

    d "Так что постарайся вспомнить."

    show portrait:
        xalign 0.5
        yalign 0.3

    hide draco neutral2

    "Портрет раздражённо откинулся в кресле."

    p "В доме была ужасная суета."

    p "Министерские крысы сновали по коридорам. Эльфы бегали туда-сюда."

    p "А потом умер Люциус."

    hide portrait

    show draco neutral2 

    d "Что было после?"

    show portrait:
        xalign 0.5
        yalign 0.3

    hide draco neutral2

    "Портрет задумался."

    p "Из комнаты вышел старый эльф."

    hide portrait

    show draco neutral2 

    d "Тибби?"

    show portrait:
        xalign 0.5
        yalign 0.3

    hide draco neutral2

    p "Кажется, так его звали."

    p "Только он не пошёл звать остальных."

    hide portrait

    show draco neutral2 

    "Драко нахмурился."

    d "А куда он пошёл?"

    show portrait:
        xalign 0.5
        yalign 0.3

    hide draco neutral2

    p "Наверх."

    hide portrait

    show draco neutral2 

    d "Наверх?"

    show portrait:
        xalign 0.5
        yalign 0.3

    hide draco neutral2

    p "По лестнице в старую часть дома."

    p "Вернулся он не сразу."

    hide draco neutral2

    show herm neutral 

    hide portrait

    h "Сколько его не было?"

    hide herm neutral

    show portrait:
        xalign 0.5
        yalign 0.3


    "Портрет снова посмотрел на Гермиону с явным неудовольствием."    

    p "Я не часы, девчонка."

    hide portrait

    show draco neutral2 

    d "Ответь ей."

    show portrait:
        xalign 0.5
        yalign 0.3

    hide draco neutral2

    "Портрет недовольно поморщился."

    p "Минут пятнадцать."

    p "Может, двадцать."

    hide portrait

    show draco neutral2 

    d "А потом?"

    show portrait:
        xalign 0.5
        yalign 0.3

    hide draco neutral2

    p "Спустился обратно."

    p "Прошёл мимо меня и отправился искать другого эльфа."

    hide portrait

    show herm neutral 

    h "Миппи."

    show portrait:
        xalign 0.5
        yalign 0.3

    hide herm neutral

    p "Если тебе так нравится."

    show herm neutral

    hide portrait
 
    "Гермиона замолчала."

    "До сих пор они считали, что Тибби обнаружил смерть Люциуса и сразу позвал остальных."

    "Но это было не так."

    "Между этими двумя событиями оставалось пятнадцать — возможно, двадцать минут."

    "И всё это время Тибби находился где-то наверху."

    hide herm neutral

    show draco neutral2 

    d "В старой части дома почти ничего нет."

    hide draco neutral2

    show herm neutral 

    h "Почти?"

    hide herm neutral

    show draco neutral2 

    "Драко несколько секунд смотрел на неё."

    "А затем, кажется, понял то же, что и она."

    d "Комнаты домовиков."

    hide draco neutral2

    show herm neutral 

    h "Где жил Тибби?"

    hide herm neutral

    show draco neutral2 

    d "Наверху."

    "Этого оказалось достаточно."

    stop music fadeout 3.0
    hide draco neutral2

    jump scene_10_tibby_room