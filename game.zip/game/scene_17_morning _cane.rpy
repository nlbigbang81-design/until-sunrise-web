label scene_17_morning_cane:

    scene malfoy hall light
    with Dissolve(1.0)

   
    stop music fadeout 3.0

    play music "audio/Suspended Shadows.mp3" loop fadein 3.0 

    "Трость лежала там же, где они оставили её ночью."

    "Утро ничего не изменило."

    "В гостиной было непривычно светло."

    "Не солнечно — за высокими окнами всё ещё висело серое небо, а мокрый сад казался почти бесцветным."

    "Но после вчерашних свечей и огня в камине утренний свет делал комнату другой."

    "Слишком настоящей."

    "На небольшом столе уже ждал завтрак."

    "Кофе, чай, тосты, фрукты — Миппи, похоже, решила не выяснять заранее, чего именно захочет гостья."

    show draco neutral2 

    d "Позавтракаешь?"

    hide draco neutral2

    show herm neutral 

    "Гермиона посмотрела на стол."

    "В другое утро она бы согласилась."

    h "Спасибо."

    "Она чуть улыбнулась."

    h "Но, думаю, мне уже пора."

    hide herm neutral

    show draco neutral2 

    "Драко не стал спорить."

    d "Кофе хотя бы?"

    hide draco neutral2

    show herm neutral 

    h "Кофе можно."

    "Он налил ей чашку."

    "Гермиона взяла её и только тогда посмотрела в другой конец комнаты."

    "На письменный стол."

    "Трость лежала там же, где они оставили её ночью."

    "Аккуратно завёрнутая в ткань."

    "Утро ничего не изменило."

    "Три имени всё ещё были внутри."

    "Как и воспоминания, которые могли изменить жизнь Драко."

    "Гермиона поставила чашку."

    hide herm neutral

    show draco neutral2 

    "Драко проследил за её взглядом."

    "Несколько секунд оба молчали."

    d "Ну что, Грейнджер?"

    "Он кивнул в сторону стола."

    d "Что мы делаем с тростью?"

    hide draco neutral2

    show herm neutral 

    "Вчера они решили оставить этот вопрос до утра."

    "Утро наступило."

    "Ответ легче не стал."

    menu:

        "Оставить трость Драко":
            $ cane_choice = "draco"
            jump cane_leave_draco

        "Удалить воспоминания о сотрудниках\nМинистерства":
            $ cane_choice = "remove"
            jump cane_remove_memories

        "Передать трость Министерству\nбез изменений":
            $ cane_choice = "ministry"
            jump cane_give_ministry


# ============================================================
# ОСТАВИТЬ ТРОСТЬ ДРАКО
# ============================================================

label cane_leave_draco:

    
    "Гермиона подошла к столу."

    "Несколько секунд смотрела на свёрток."

    "А потом отступила."

    h "Она останется здесь."

    hide herm neutral

    show draco neutral2 

    "Драко нахмурился."

    d "Со мной?"

    hide draco neutral2

    show herm neutral 

    h "С тобой."

    hide herm neutral

    show draco neutral2 

    "Он посмотрел сначала на трость, потом на Гермиону."

    d "И что, по-твоему, я должен с ней сделать?"

    hide draco neutral2

    show herm neutral 

    h "Не знаю."

    hide herm neutral

    show draco neutral2 

    d "Убедительно."

    hide draco neutral2

    show herm neutral 

    h "Я серьёзно."

    "Гермиона повернулась к нему."

    h "Я сделаю вид, что вчера её не нашла."

    hide herm neutral

    show draco neutral2 

    "Улыбка исчезла с лица Драко."

    hide draco neutral2

    show herm neutral 

    h "В отчёте будет указано, что местонахождение трости Люциуса Малфоя установить не удалось."

    hide herm neutral

    show draco neutral2 

    d "Ты солжёшь Министерству."

    hide draco neutral2

    show herm neutral 

    h "Да."

    "Слово прозвучало неприятно просто."

    hide herm neutral

    show draco neutral2 

    d "Ради меня?"

    hide draco neutral2

    show herm neutral 

    h "Нет."

    hide herm neutral

    show draco neutral2 

    "Драко слегка приподнял бровь."

    hide draco neutral2

    show herm neutral 

    h "И не ради них."

    "Она посмотрела на трость."

    h "Я просто больше не уверена, что Министерство — единственное место, которому можно доверить решение о том, что находится внутри."

    hide herm neutral

    show draco neutral2 

    "Драко ничего не сказал."

    hide draco neutral2

    show herm neutral 

    h "Дальше решать тебе."

    hide herm neutral

    show draco neutral2 

    d "Ты понимаешь, что именно сейчас мне доверяешь?"

    hide draco neutral2

    show herm neutral 

    h "К сожалению."

    hide herm neutral

    show draco neutral2 

    "В уголках его губ появилась улыбка."

    hide draco neutral2

    show herm neutral 

    h "Не заставляй меня об этом пожалеть."

    hide herm neutral

    show draco neutral2 

    d "Постараюсь."

    hide draco neutral2

    show herm neutral 

    "Гермиона посмотрела на него."

    h "Это совершенно не успокаивает."

    jump cane_choice_done


# ============================================================
# УДАЛИТЬ ТРИ ВОСПОМИНАНИЯ
# ============================================================

label cane_remove_memories:

    show herm neutral 

    "Гермиона подошла к столу и развернула ткань."

    "Тёмное дерево трости тускло блеснуло в сером утреннем свете."

    h "Я удалю три воспоминания."

    hide herm neutral

    show draco neutral2 

    "Драко не ответил сразу."

    d "Уинстон. Хартли. Мортон."

    hide draco neutral2

    show herm neutral 

    h "Да."

    hide herm neutral

    show draco neutral2 

    d "А остальные?"

    hide draco neutral2

    show herm neutral 

    h "Останутся."

    "Она провела пальцами над рукоятью, не касаясь её."

    h "В том числе те, которые касаются тебя."

    hide herm neutral

    show draco neutral2 

    "Драко внимательно смотрел на неё."

    d "То есть трость получит Министерство."

    hide draco neutral2

    show herm neutral 

    h "Да."

    hide herm neutral

    show draco neutral2 

    d "Она поможет пересмотреть моё дело."

    hide draco neutral2

    show herm neutral 

    h "Не поможет."

    hide herm neutral

    show draco neutral2 

    "Драко вопросительно посмотрел на неё."

    hide draco neutral2

    show herm neutral 

    h "Я потребую пересмотра твоего дела на основании новых доказательств."

    hide herm neutral

    show draco neutral2 

    d "А три человека, чьи имена должны были оказаться в том же расследовании, останутся в стороне."

    hide draco neutral2

    show herm neutral 

    "Гермиона сжала губы."

    h "Я знаю, как это звучит."

    hide herm neutral

    show draco neutral2 

    d "Я не уверен, что знаешь."

    hide draco neutral2

    show herm neutral 

    "Она подняла на него взгляд."

    hide herm neutral

    show draco neutral2 

    d "Ты собираешься вмешаться в структуру тёмного артефакта."

    d "Если кто-нибудь заметит следы..."

    hide draco neutral2

    show herm neutral 

    h "Я знаю."

    hide herm neutral

    show draco neutral2 

    d "Первой спросят тебя."

    hide draco neutral2

    show herm neutral 

    h "Я знаю."

    hide herm neutral

    show draco neutral2 

    d "Твоя карьера."

    hide draco neutral2

    show herm neutral 

    h "Малфой."

    hide herm neutral

    show draco neutral2 

    d "Твоя репутация."

    hide draco neutral2

    show herm neutral 

    h "Я всё это понимаю."

    hide herm neutral

    show draco neutral2 

    "Он замолчал."

    "В его лице не было злости."

    d "Они стоят того?"

    hide draco neutral2

    show herm neutral 

    h "Я не знаю."

    hide herm neutral

    show draco neutral2 

    d "Тогда зачем?"

    hide draco neutral2

    show herm neutral 

    "Гермиона снова посмотрела на трость."

    h "Потому что я знаю этих людей."

    h "Я знаю их семьи."

    h "Я знаю, кем они были последние десять лет."

    hide herm neutral

    show draco neutral2 

    d "А кем они были тогда?"

    hide draco neutral2

    show herm neutral 

    "Гермиона не ответила."

    hide herm neutral

    show draco neutral2 

    "Драко тихо выдохнул."

    d "Ладно."

    "Он помолчал."

    d "Тогда другой вопрос."

    hide draco neutral2

    show herm neutral 

    "Гермиона посмотрела на него."

    hide herm neutral

    show draco neutral2 

    d "Я стою твоей карьеры?"

    hide draco neutral2

    show herm neutral 

    "Она замерла."

    hide herm neutral

    show draco neutral2 

    d "Потому что если убрать всё остальное, именно это ты собираешься сделать."

    d "Рискнуть своей репутацией, чтобы восстановить мою."

    hide draco neutral2

    show herm neutral 

    "Гермиона нахмурилась."

    h "Не льсти себе."

    hide herm neutral

    show draco neutral2 

    "Драко усмехнулся, но взгляд остался серьёзным."

    hide draco neutral2

    show herm neutral 

    h "Я делаю это не ради тебя."

    hide herm neutral

    show draco neutral2 

    d "Конечно."

    hide draco neutral2

    show herm neutral 

    h "Малфой."

    hide herm neutral

    show draco neutral2 

    d "Молчу."

    hide draco neutral2

    show herm neutral 

    "Гермиона снова посмотрела на трость."

    "Теперь решение казалось ещё тяжелее."

    "Но оно уже было принято."

    jump cane_choice_done


# ============================================================
# ОТДАТЬ ТРОСТЬ МИНИСТЕРСТВУ ЦЕЛИКОМ
# ============================================================

label cane_give_ministry:

    show herm neutral 

    "Гермиона долго смотрела на трость."

    "Потом взяла её со стола."

    h "Я передам её Министерству."

    hide herm neutral

    show draco neutral2 

    "Драко не пошевелился."

    hide draco neutral2

    show herm neutral 

    h "Как есть."

    hide herm neutral

    show draco neutral2 

    "Несколько секунд он молчал."

    d "Все воспоминания."

    hide draco neutral2

    show herm neutral 

    h "Все."

    hide herm neutral

    show draco neutral2 

    d "И три имени."

    hide draco neutral2

    show herm neutral 

    h "Да."

    hide herm neutral

    show draco neutral2 

    "Драко медленно кивнул."

    d "Я не сомневался в тебе, Грейнджер."

    hide draco neutral2

    show herm neutral 

    "Гермиона подозрительно прищурилась."

    hide herm neutral

    show draco neutral2 

    d "Ты всё-таки выбрала самый правильный вариант."

    hide draco neutral2

    show herm neutral 

    h "Не начинай."

    hide herm neutral

    show draco neutral2 

    d "Что?"

    hide draco neutral2

    show herm neutral 

    h "Вот это самодовольное «я знал, что ты поступишь правильно»."

    hide herm neutral

    show draco neutral2 

    d "Но я действительно знал."

    hide draco neutral2

    show herm neutral 

    h "Ещё слово — и я оставлю её тебе."

    hide herm neutral

    show draco neutral2 

    "Драко усмехнулся."

    d "Молчу."

    hide draco neutral2

    show herm neutral 

    "Гермиона снова посмотрела на трость."

    "Правильный вариант."

    "Ей хотелось бы верить, что такие ещё существовали."

    h "Я не знаю, правильно ли это."

    hide herm neutral

    show draco neutral2 

    "Улыбка Драко стала слабее."

    hide draco neutral2

    show herm neutral 

    h "Я просто не думаю, что имею право решать, какие доказательства должны существовать, а какие — нет."

    hide herm neutral

    show draco neutral2 

    d "Это звучит подозрительно похоже на правильный ответ."

    hide draco neutral2

    show herm neutral 

    h "Малфой."

    hide herm neutral

    show draco neutral2 

    d "Всё. Теперь точно молчу."

    jump cane_choice_done


# ============================================================
# ОБЩАЯ ТОЧКА
# ============================================================

label cane_choice_done:

    hide draco neutral2
    hide herm neutral

    "Решение было принято."

    "Гермиона выдохнула."

    "И только сейчас поняла, насколько устала от этого выбора."

    "Впервые за утро ей стало немного легче."

    stop music fadeout 3.0


    jump scene_18_morning_goodbye