﻿define h = Character("Гермиона", color="#c8a97e")

define d = Character("Драко", color="#c8a97e")

define m = Character("Миппи", color="#d8c6a3")

define p = Character ("Портрет",  color="#c8a97e")

default draco_warmth = 0

default draco_tension = 0

default draco_sex = False

default runi = False

default draco_dinner = False

default cane_choice = "none"


label start:
   
   jump scene_1_malfoy_manor

   