label scene_05_lucius_argument:

    # Перед этим:
    # h "Что ты знаешь о последних часах жизни Люциуса?"

    scene malfoy hall
    with Dissolve(1.5)

    play music "audio/Sombra Aristocratica.mp3" loop fadein 3.0


    hide herm neutral

    show draco whiskey 

    "Драко несколько секунд молчал."

    "В его лице появилось напряжение, которого раньше не было."

    d "Немного."

    hide draco whiskey

    show herm neutral 

    h "Что значит «немного»?"

    hide herm neutral

    show draco whiskey 

    d "Ровно то, что значит."

    d "Я не был здесь, когда он умер."

    hide draco whiskey

    show herm neutral 

    h "Но кто-то был."

    h "Твоя мать. Домовики. Возможно, кто-то из сотрудников поместья."

    hide herm neutral

    show draco whiskey 

    d "Нарцисса уехала через несколько дней после его смерти."

    d "А домовиков Министерство тогда едва ли считало достойными полноценного допроса."

    hide draco whiskey

    show herm neutral 

    "Гермиона нахмурилась."

    h "Но трость принадлежала Люциусу."

    h "Она находилась здесь."

    h "И после его смерти исчезла."

    hide herm neutral

    show draco whiskey 

    d "Да."

    hide draco whiskey

    show herm neutral 

    h "Значит, логично предположить, что кто-то в Мэноре мог её спрятать."

    hide herm neutral

    show draco whiskey 

    "Драко медленно поставил стакан на стол."

    hide draco whiskey
    show draco neutral2 

    d "Логично."

    d "Если забыть одну маленькую деталь."

    hide draco neutral2

    show herm neutral 

    h "Какую?"

    hide herm neutral

    show draco neutral2 

    d "В тот момент, когда мой отец умер, я сидел под стражей Министерства."

    d "А в этом доме находились ваши люди."

    hide draco neutral2

    show herm neutral 

    h "Мы это уже обсуждали."

    hide herm neutral

    show draco neutral2 

    d "Нет, Грейнджер."

    d "Ты задавала вопросы."

    d "А теперь, возможно, впервые пытаешься услышать ответ."

    "В его голосе исчезла ленивость."

    d "Авроры вскрывали комнаты."

    d "Хранилища."

    d "Семейные сейфы."

    d "Проверяли стены, полы, защитные чары."

    d "Из Мэнора вывозили ящики с вещами моей семьи."

    d "Я вернулся сюда спустя месяцы."

    "Он посмотрел на неё прямо."

    d "Так почему именно я должен объяснять тебе, куда исчез предмет, который потерялся во время вашего обыска?"

    hide draco neutral2

    show herm neutral 

    h "Потому что трости нет в описи."

    h "Если бы её конфисковало Министерство, она должна была быть зарегистрирована."

    hide herm neutral

    show draco neutral2 

    d "Должна была."

    hide draco neutral2

    show herm neutral 

    h "Ты опять это говоришь."

    hide herm neutral

    show draco neutral2 

    d "Потому что ты продолжаешь говорить о Министерстве так, будто оно физически не способно потерять вещь."

    hide draco neutral2

    show herm neutral 

    h "А ты говоришь о собственной семье так, будто Малфои никогда ничего не скрывали."

    hide herm neutral

    show draco neutral2 

    "Его взгляд стал холоднее."

    d "Осторожнее, Грейнджер."

    hide draco neutral2

    show herm neutral 

    h "Я не обвиняю тебя."

    hide herm neutral

    show draco neutral2 

    d "Нет?"

    d "Ты сидишь в моём доме и уже второй раз за вечер объясняешь мне, что кто-то из моей семьи, вероятно, спрятал тёмный артефакт."

    hide draco neutral2

    show herm neutral 

    h "Потому что это одна из версий."

    hide herm neutral

    show draco neutral2 

    d "А версия о том, что Министерство облажалось, видимо, настолько невероятна, что даже не заслуживает рассмотрения."

    hide draco neutral2

    show herm neutral 

    "Гермиона почувствовала, как внутри поднимается раздражение."

    "Но вместе с ним пришла и неприятная мысль."

    "Он действительно не говорил ничего невозможного."


    menu:

        "Попытаться понять его":

            $ draco_warmth += 1

            h "Хорошо."

            h "Допустим, ты прав."

            hide herm neutral

            show draco neutral2 

            "Драко чуть приподнял бровь."

            d "Прости?"

            hide draco neutral2

            show herm neutral 

            h "Не привыкай."

            h "Я сказала: допустим."

            h "Министерство могло допустить ошибку."

            h "Кто-то мог не зарегистрировать находку. Кто-то мог переложить её не в тот ящик. Документы могли потеряться."

            "Она немного помолчала."

            h "И ты действительно не мог знать, что происходило здесь в те дни."

            hide herm neutral

            show draco neutral2 

            "Несколько секунд Драко просто смотрел на неё."

            d "Это почти похоже на извинение."

            hide draco neutral2

            show herm neutral 

            h "Не увлекайся."

            hide herm neutral

            show draco neutral2 

            "Уголок его губ едва заметно дрогнул."

            d "Разумеется."

            d "Но я запомню этот исторический момент."

            jump after_cane_argument


        "Не уступать Малфою":

            $ draco_tension += 1

            h "Очень удобная версия."

            hide herm neutral

            show draco neutral2 

            d "Она становится менее удобной оттого, что тебе не нравится?"

            hide draco neutral2

            show herm neutral 

            h "Нет."

            h "Но отсутствие твоего имени в доме в день обыска ещё не означает, что семья ничего не знала."

            hide herm neutral

            show draco neutral2 

            d "А отсутствие трости в реестре, видимо, не означает, что Министерство ничего не знает."

            hide draco neutral2

            show herm neutral 

            h "У нас есть процедуры."

            hide herm neutral

            show draco neutral2 

            d "Какая невероятно успокаивающая мысль."

            hide draco neutral2

            show herm neutral 

            h "Ты невыносим."

            hide herm neutral

            show draco neutral2 

            d "А ты всё ещё здесь."

            "На мгновение Гермиона потеряла нить разговора."

            hide draco neutral2

            show herm neutral 

            h "Из-за шторма."

            hide herm neutral

            show draco neutral2 

            "На этот раз он всё-таки усмехнулся."

            d "Конечно."

            jump after_cane_argument


        "Вернуться к фактам":

            h "Спорить можно всю ночь."

            h "Это не приблизит нас к трости."

            hide herm neutral

            show draco neutral2 

            d "Редкий момент здравого смысла."

            hide draco neutral2

            show herm neutral 

            h "Я могу передумать."

            hide herm neutral

            show draco neutral2 

            d "Тогда продолжай."

            jump after_cane_argument


label after_cane_argument:

    "Раздражение постепенно отступило."

    "Гермиона сделала небольшой глоток вина."

    "Если отбросить взаимные обвинения, оставалась простая проблема."

    "Они оба понятия не имели, где оказалась трость."

    hide draco neutral2

    show herm neutral 

    h "Хорошо."

    h "Попробуем с самого начала."

    hide herm neutral

    show draco neutral2 

    d "Как воодушевляюще."

    hide draco neutral2

    show herm neutral 

    h "Кто находился в Мэноре в день смерти твоего отца?"

    hide herm neutral

    show draco neutral2 

    d "Мать."

    d "Несколько домовиков."

    d "Целитель приезжал утром."

    "Он задумался."

    d "И, насколько мне известно, больше никого."

    hide draco neutral2

    show herm neutral 

    h "Домовиков допрашивали?"

    hide herm neutral

    show draco neutral2 

    "Драко нахмурился."

    d "Не знаю."

    hide draco neutral2

    show herm neutral 

    h "Совсем?"

    hide herm neutral

    show draco neutral2 

    d "Грейнджер, я в третий раз напоминаю тебе, что меня здесь не было."

    hide draco neutral2

    show herm neutral 

    h "Я знаю."

    "Но теперь Гермиона уже почти не слушала его раздражение."

    "В её голове начала складываться новая цепочка вопросов."

    stop music fadeout 3.0


    jump scene_06_investigation