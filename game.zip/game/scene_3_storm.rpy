label scene_03_storm:

    scene manor window

    with Dissolve(1.5)

    play music "audio/rain_theme.mp3" loop fadein 3.0

    "За окнами снова вспыхнула молния."

    "На этот раз свет был странным — не белым, а с едва заметным фиолетовым оттенком."

    "Следом по дому прошёлся низкий раскат грома." 

    show draco neutral 


    "Драко нахмурился."

    d "Мне не нравится эта гроза."

    hide draco neutral

    show herm neutral 

    h "Ты боишься грома?"

    hide herm neutral

    show draco neutral 

    "Он медленно перевёл на неё взгляд."

    d "Потрясающе остроумно."

    hide draco neutral

    show herm neutral 

    h "Спасибо."

    hide herm neutral

    "Новая вспышка осветила окна."

    "По стеклу на мгновение пробежали тонкие голубоватые искры."

    show herm sad2 

    "Улыбка исчезла с лица Гермионы."

    h "Это были защитные чары?"

    hide herm sad2

    show draco neutral 

    d "Нет."

   
    d "Обычная гроза не должна взаимодействовать с внешним контуром Мэнора."

    hide draco neutral

    show herm neutral 

    h "Магический шторм?"

    hide herm neutral

    show draco neutral 

    d "Похоже на то."

    hide draco neutral

    "Гермиона подошла к окну."
    

    "За пределами дома дождь будто стал ещё плотнее."

    "Вдалеке над деревьями снова озарилось небо."

    hide draco neutral

    show herm neutral 

    h "Давно началось?"

    hide herm neutral

    show draco neutral 

    d "Когда ты пришла, это была просто гроза."

    hide draco neutral

    show herm neutral 

    h "Прекрасно."

    hide herm neutral

    show draco neutral 

    d "Кажется, сегодня это твоё любимое слово."

    hide draco neutral

    show herm neutral 

    h "Я собиралась домой."

    hide herm neutral

    show draco neutral 

    d "Тогда советую поторопиться."

    hide draco neutral

    show herm angry1 

    "Гермиона бросила на него недовольный взгляд."

    h "Очень смешно."

    "Она потянулась за сумкой."

    h "Я воспользуюсь камином."

    hide herm angry1

    show draco neutral 

    "Драко ничего не ответил."

    "Это молчание ей не понравилось."

    hide draco neutral

    show herm neutral 

    h "Что?"

    hide herm neutral

    show draco neutral 

    d "Попробуй."

    hide draco neutral

    stop music fadeout 3.0


    play music "audio/Suspended Harmony.mp3" loop fadein 3.0
    
    scene manor fire

    "Они прошли к большому камину."

    "Гермиона взяла из небольшой чаши горсть Летучего пороха и бросила её в огонь."

    hide draco neutral

    show herm neutral 

    h "Министерство магии."

    "Пламя на мгновение стало ярко-зелёным."

    "А затем резко погасло."

    "Гермиона замерла."

    h "Ещё раз."

    "Она бросила новую горсть."

    h "Министерство магии!"

    "Ничего."

    "Обычное оранжевое пламя продолжало спокойно гореть."

    hide herm neutral

    show draco neutral 

    d "Сеть не отвечает."

    hide draco neutral

    show herm neutral 

    h "Я вижу."

    hide herm neutral

    show draco neutral 

    d "Рад, что десять лет надзора хотя бы не повлияли на твою наблюдательность."

    hide draco neutral

    show herm neutral 

    h "Малфой."

    hide herm neutral

    show draco neutral 

    d "Грейнджер."

    hide draco neutral

    show herm neutral 

    "Гермиона отошла от камина."

    h "Тогда я аппарирую."

    hide herm neutral

    show draco neutral 

    "Драко посмотрел на неё уже совершенно серьёзно."

    d "Нет."

    hide draco neutral

    show herm neutral 

    h "Прошу прощения?"

    hide herm neutral

    show draco neutral 

    d "Во время такого шторма?"

    hide draco neutral

    show herm neutral 

    h "Я умею аппарировать."

    hide herm neutral

    show draco neutral 

    d "Какое счастье."

    d "Но если магический фон уже нарушил каминную сеть и защитные чары Мэнора, я бы не советовал проверять, насколько хорошо он влияет на расщепление."

    "Гермиона промолчала."

    "Он был прав."

    "И именно это раздражало сильнее всего."

    hide draco neutral

    show herm neutral 

    h "Можно попробовать у границы защитного контура."

    hide herm neutral

    show draco neutral 

    d "Можно."

    d "А можно не терять конечности из принципа."

    hide draco neutral

    show herm neutral 

    h "Ты всегда настолько ободряюще разговариваешь с гостями?"

    hide herm neutral

    show draco neutral 

    d "Только с теми, кто пытается убиться на моей территории."

    "Ещё один раскат грома заставил задрожать стёкла."

    "Гермиона посмотрела на окна."

    hide draco neutral

    show herm neutral 

    h "И сколько это может продолжаться?"

    hide herm neutral

    show draco neutral 

    d "Час."

    "Он пожал плечами."

    d "Или всю ночь."

    hide draco neutral

    show herm neutral 

    "Гермиона нехотя повернулась к нему."

    h "Всю ночь?"

    hide herm neutral

    show draco neutral 

    d "Это была приблизительная оценка."

    hide draco neutral

    show herm neutral 

    h "Очень утешительно."

    hide herm neutral

    show draco neutral 

    "Драко прислонился плечом к каминной полке."

    d "Если хочешь, можешь продолжать стоять здесь и смотреть на огонь."

    d "Но боюсь, он не начнёт работать от твоего неодобрения."

    hide draco neutral

    show herm neutral 

    "Гермиона скрестила руки на груди."

    h "Значит, я застряла здесь."

    hide herm neutral

    show draco neutral 

    d "По всей видимости."

    "Повисла короткая пауза."

    d "Со мной."

    hide draco neutral

    show herm neutral 

    "Гермиона закрыла глаза."

    h "Вот теперь вечер действительно стал прекрасным."

    hide herm neutral

    show draco neutral 

    "На этот раз Драко всё-таки усмехнулся."

    stop music fadeout 3.0


    jump scene_04_evening