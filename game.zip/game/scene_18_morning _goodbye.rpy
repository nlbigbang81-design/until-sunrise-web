label scene_18_morning_goodbye:

    scene malfoy_manor_morning
    with Dissolve(1.5)

    
    stop music fadeout 3.0

    play music "audio/zvuk-ptic-utrom.mp3" loop fadein 3.0 

    "К тому времени, когда они вышли из Мэнора, погода успела перемениться."

    "Серое утреннее небо расчистилось, и поместье заливал солнечный свет."

    "Каменные ступени ещё блестели после дождя, но следы ночной грозы уже высыхали на солнце."

    "Гермиона остановилась у дверей и вдохнула прохладный воздух."

    "После душного Мэнора он казался особенно свежим."

    show draco coat 

    d "Я тебя провожу."

    hide draco coat

    show herm neutral coat 

    h "Не надо."

    "Драко вопросительно посмотрел на неё."

    h "Я хочу пройтись одна."

    h "Мне нужно немного проветрить голову."

    hide herm neutral coat

    show draco coat 

    d "После одной ночи в моём обществе?"

    hide draco coat

    show herm neutral coat 

    h "Именно."

    hide herm neutral coat

    show draco coat 

    "Драко усмехнулся."

    d "Тогда не смею мешать."

    if draco_warmth + draco_tension >= 5 and draco_sex == True:

        "Гермиона уже собиралась спуститься по ступеням, когда он снова заговорил."

        d "Грейнджер."

        hide draco coat

        show herm neutral coat 

        "Она обернулась."

        hide herm neutral coat

        show draco coat 

        d "Как насчёт начала?"

        hide draco coat

        show herm neutral coat 

        "Гермиона приподняла бровь."

        h "Начала?"

        hide herm neutral coat

        show draco coat 

        d "Ты сказала, что нормальные люди начинают с ужина."

        "В его глазах мелькнула знакомая насмешка."

        d "Начнём с ужина в воскресенье?"

        menu:

            "Согласиться на ужин":
                $ draco_dinner = True
                jump goodbye_draco_yes

            "Оставить эту ночь в прошлом":
                $ draco_dinner = False
                jump goodbye_draco_no


        label goodbye_draco_yes:

            hide draco coat

            show herm neutral coat 

            "Гермиона посмотрела на него."

            "А потом улыбнулась."

            h "В воскресенье."

            hide herm neutral coat

            show draco coat 

            d "В семь?"

            hide draco coat

            show herm neutral coat 

            h "В восемь."

            hide herm neutral coat

            show draco coat 

            d "Грейнджер, ты уже торгуешься?"

            hide draco coat

            show herm neutral coat 

            h "Привыкай."

            jump scene_19_finish


        label goodbye_draco_no:

            hide draco coat

            show herm neutral coat 

            "Гермиона некоторое время смотрела на него."

            h "Не думаю, Малфой."

            hide herm neutral coat

            show draco coat 

            "Он задержал на ней взгляд."

            "Потом кивнул."

            d "Что ж."

            "На его губах появилась лёгкая улыбка."

            d "Попытаться стоило."

            hide draco coat

            show herm neutral coat 

            h "Определённо."

            jump scene_19_finish

    if draco_warmth + draco_tension >= 5 and draco_sex == False:

        d "Грейнджер."

        h "Что?"

        d "Ужин в воскресенье?"

        h "Это приглашение?"

        d "Полагаю, именно так они обычно и звучат."

        menu:
            "Согласиться":
                $ draco_dinner = True

                "Гермиона едва заметно улыбнулась."

                h "В восемь."

                d "Я запомню."

                jump scena_19_finish


            "Отказаться":
                $ draco_dinner = False

                h "Не думаю, Малфой."

                "Драко на несколько секунд задержал на ней взгляд."

                d "Что ж."

                d "Попытаться стоило."

                h "Определённо."

                jump scene_19_finish


    stop music fadeout 3.0

    jump scene_19_finish





                