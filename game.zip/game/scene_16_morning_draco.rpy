label scene_16_morning_draco:

    scene dr_room2
    with Dissolve(1.5)

    
    stop music fadeout 3.0

    play music "audio/Quiet Warmth.mp3" loop fadein 3.0

    "Утро пришло без солнца."

    "За окнами больше не было дождя, но небо оставалось низким и серым."

    "Свет медленно просачивался в спальню сквозь тяжёлые шторы."

    "Гермиона проснулась не сразу."

    "Сначала почувствовала тепло."

    "Потом — чужую руку у себя на талии."

    "И только после этого вспомнила, где находится."

    "Она не шевелилась несколько секунд."

    "В комнате было тихо."

    "Драко спал рядом, уткнувшись лицом в подушку."

    "Без привычной насмешки во взгляде он выглядел неожиданно молодым."

    "Почти беззащитным."

    "Гермиона отвернулась к окну."

    "Вчерашняя ночь вернулась к ней сразу."

    "Трость."

    "Письмо Люциуса."

    "Три имени."

    "И всё, что случилось после."

    "Она закрыла глаза."

    "Сожаления не было."

    "Это почему-то пугало сильнее всего."

    show draco naked 

    d "Ты слишком громко думаешь."

    hide draco naked

    show herm hot2 

    "Гермиона вздрогнула и повернулась."

    "Драко всё ещё лежал с закрытыми глазами."

    h "Я молчу."

    hide herm hot2

    show draco naked 

    d "Именно."

    "Он открыл один глаз."

    d "От тебя это особенно подозрительно."

    hide draco naked

    show herm hot2 

    h "Доброе утро, Малфой."

    hide herm hot2

    show draco naked 

    d "Вот теперь я начинаю волноваться."

    hide draco naked

    show herm hot2 

    "Гермиона невольно улыбнулась."

    "Драко приподнялся на локте."

    hide herm hot2

    show draco naked 

    d "Ты всегда так выглядишь утром?"

    hide draco naked

    show herm hot2 

    h "Как?"

    hide herm hot2

    show draco naked 

    d "Как человек, которому Министерство поручило расследовать собственную жизнь."

    hide draco naked

    show herm hot2 

    h "Очень смешно."

    hide herm hot2

    show draco naked 

    d "Я стараюсь."

    "Она потянулась за своей рубашкой."

    "Драко наблюдал за ней молча."

    hide draco naked

    show herm hot2 


    h "Не смотри."

    hide herm hot2

    show draco naked 

    d "Поздно."

    hide draco naked

    show herm hot2 


    "Гермиона бросила на него взгляд."

    h "Ты отвратителен."

    hide herm hot2

    show draco naked 

    d "И всё же ты здесь."

    "На этот раз она ничего не ответила."

    "Только застегнула одну пуговицу."

    "Потом вторую."

    "Драко сел на кровати."

    hide herm hot2

    show draco naked 

    d "Кофе?"

    hide draco naked

    show herm hot2 


    h "Да."

    hide herm hot2

    show draco naked 

    d "Это прозвучало так, будто от ответа зависит твоя жизнь."

    hide draco naked

    show herm hot2 


    h "Возможно, так и есть."

    hide herm hot2

    "Через несколько минут на небольшом столике у окна уже стояли две чашки."

    "Миппи появилась почти бесшумно, поставила поднос и так же быстро исчезла."

    "Гермиона взяла чашку обеими руками."

    "Кофе был горячим."

    "И очень нужным."

    "Несколько минут они молчали."

    "Странное молчание."

    "Не неловкое."

    "Просто новое."

    hide herm hot2

    show draco naked 

    d "Грейнджер."

    hide draco naked

    show herm hot2 


    h "Мм?"

    hide herm hot2

    show draco naked 

    d "Могу я рассчитывать на продолжение?"

    hide draco naked

    show herm hot2 

    "Гермиона посмотрела на него поверх чашки."

    h "Малфой, продолжение у нас уже было."

    "Драко усмехнулся."

    hide draco naked

    show herm hot2 

    h "Нормальные люди вообще-то начинают с ужина."

    hide herm hot2

    show draco naked 

    d "Резонно."

    "Он сделал глоток кофе."

    "И больше ничего не спросил."

    "Гермиона была ему за это благодарна."

    hide draco naked

    show herm hot2 

    "Гермиона допила кофе и поставила чашку на стол."

    h "Мне нужно привести себя в порядок."

    hide herm hot2

    show draco naked 

    d "Ванная там."

    "Драко кивнул на дверь в дальнем конце спальни."

    hide herm hot2

    show draco naked 

    d "Полотенца найдёшь внутри."

    hide draco naked

    show herm hot2 

    h "Спасибо."

    "Она поднялась с кровати, собирая по пути оставленную вчера одежду."

    hide herm hot2

    show draco naked 

    d "Грейнджер."

    "Гермиона обернулась."

    "Драко протягивал ей брюки, которые она не заметила у края кровати."

    hide draco naked

    show herm hot2 

    h "Спасибо."

    hide herm hot2

    show draco naked 

    d "Не за что."

    "На этот раз его улыбка была почти невинной."

    hide draco naked

    show herm hot2 

    h "Даже не начинай."

    hide herm hot2

    show draco naked 

    d "Я ничего не сказал."

    hide draco naked

    show herm hot2 

    "Она забрала блузку и скрылась за дверью ванной."

    scene black
    with Dissolve(0.5)

    pause 0.5

    scene dr_room2
    with Dissolve(0.5)

    "Когда Гермиона вернулась, она снова выглядела почти как человек, который вчера прибыл в Мэнор с официальной проверкой."

    "Почти."

    show draco neutral2 


    "Драко уже был одет."

    "На нём снова была белая рубашка, тёмные брюки и то самое невозмутимое выражение лица, с которым он встретил её вчера у дверей."

    "После прошедшей ночи оно уже никого не могло обмануть."

    d "Готова?"

    hide draco neutral2

    show herm neutral 

    "Гермиона на мгновение задержалась."

    h "Нет."

    hide herm neutral

    show draco neutral2 

    "Драко посмотрел на неё."

    hide draco neutral2

    show herm neutral 

    h "Но, полагаю, это ничего не меняет."

    hide draco neutral2

    show herm neutral 

    d "Боюсь, что нет."

    "Он открыл дверь."

    d "Пойдём."

    
    stop music fadeout 3.0

    jump scene_17_morning_cane
                