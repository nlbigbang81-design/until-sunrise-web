label scene_08_reconstruct_night:

    scene malfoy hall
    with dissolve

    play music "audio/Candlelit Tension.mp3" loop fadein 3.0


    show herm neutral 

    "Гермиона ещё некоторое время смотрела на Миппи."

    "Чем больше подробностей всплывало, тем менее полезным казался один и тот же вопрос."

    "Кто взял трость?"

    "Слишком много людей находилось в Мэноре."

    "Слишком многое происходило одновременно."

    h "Давайте пока забудем о трости."

    hide herm neutral

    show draco neutral2 

    d "Неожиданное предложение от человека, который весь вечер ищет трость."

    hide draco neutral2

    show herm neutral 

    h "Мы пытаемся угадать, кто мог её взять."

    h "А сначала стоило выяснить, когда она вообще могла исчезнуть."

    hide herm neutral

    show draco neutral2 

    d "Продолжай."

    hide draco neutral2

    show herm neutral 

    "Гермиона подошла к столу и подтянула к себе чистый лист пергамента."

    "Несколькими движениями палочки она провела на нём горизонтальную линию."

    h "Начнём с вечера."

    h "Миппи, когда Нарцисса вернулась из Министерства?"

    hide herm neutral

    show mippy neutral 

    m "Поздно, мисс."

    m "Уже стемнело."

    m "Госпожа была очень уставшая."

    m "Миппи проводила её наверх."

    hide mippy neutral

    show herm neutral 

    "На пергаменте появилась первая отметка."

    h "Нарцисса возвращается из Министерства."

    h "Спрашивает о Люциусе."

    h "И уходит спать."

    "Следом появилась ещё одна линия."

    h "Люциус в это время ещё жив."

    h "Его состояние ухудшается."

    h "Тибби остаётся с ним."

    hide herm neutral

    show draco neutral2 

    d "И в доме всё ещё находятся авроры."

    hide draco neutral2

    show herm neutral 

    h "Да."

    "Ещё несколько имён легли на пергамент."

    "Нарцисса."

    "Люциус."

    "Тибби."

    "Миппи."

    "Авроры."

    "Целитель."

    h "Получается достаточно много людей."

    hide herm neutral

    show draco neutral2 

    d "Прекрасно."

    d "Подозреваем половину Мэнора."

    hide draco neutral2

    show herm neutral 

    h "Нет."

    h "Пока мы просто перестали подозревать исключительно твою семью."

    hide herm neutral

    show draco neutral2 

    "Уголок его рта едва заметно дрогнул."

    d "Уже прогресс."


    # --- ВЫБОР ПО НАРЦИССЕ ---

    hide draco neutral2

    show herm neutral 

    "Гермиона снова посмотрела на имя Нарциссы."

    menu:

        "Оставить Нарциссу в списке":

            h "Нарциссу пока не исключаем."

            hide herm neutral

            show draco neutral2 

            d "Миппи сказала, что мать спала."

            hide draco neutral2

            show herm neutral 

            h "Я слышала."

            h "Но сейчас мы восстанавливаем факты."

            h "Пока её перемещения не подтверждены, она остаётся в списке."

            hide herm neutral

            show draco neutral2 

            "Драко явно не понравился ответ."

            "Но спорить он не стал."


        "Исключить Нарциссу":

            $ draco_warmth += 1

            h "Нет."

            h "Нарциссу можно вычеркнуть."

            hide herm neutral

            show draco neutral2 

            d "Вот так просто?"

            hide draco neutral2

            show herm neutral 

            h "Не просто."

            h "Она провела несколько часов на допросе."

            h "Вернулась почти без сил."

            h "И прекрасно знала, что Министерство продолжит обыскивать Мэнор."

            h "Прятать здесь опасный тёмный артефакт было бы бессмысленным риском."

            h "Особенно после того, как её саму признали невиновной."

            "Гермиона ненадолго задумалась."

            h "И твоя мать всю войну пыталась сохранить семью."

            h "Не думаю, что после её окончания она стала бы хранить в доме вещь, которая снова могла поставить под удар тебя."

            hide herm neutral

            show draco neutral2 

            "Драко посмотрел на неё внимательнее."

            d "Мать была бы удивлена услышать это от тебя."

            hide draco neutral2

            show herm neutral 

            h "Не обязательно ей рассказывать."

            hide herm neutral

            show draco smile2 

            d "Непременно расскажу."

            hide draco smile2

            show herm neutral 

            h "Малфой."


        "Не позволять Драко вмешиваться":

            $ draco_tension += 1

            stop music fadeout 3.0

            play music "audio/Ticking Shadows.mp3" loop fadein 3.0


            hide herm neutral

            show draco neutral2 

            d "Мать вычеркни."

            hide draco neutral2

            show herm neutral 

            h "Нет."

            hide herm neutral

            show draco neutral2 

            d "Грейнджер."

            hide draco neutral2

            show herm neutral 

            h "Не «Грейнджер»."

            h "Ты хотел выяснить, что произошло?"

            h "Тогда не выбирай за меня удобных подозреваемых."

            hide herm neutral

            show draco neutral2 

            d "Я знаю собственную мать."

            hide draco neutral2

            show herm neutral 

            h "А я знаю, как проводится расследование."

            hide herm neutral

            show draco neutral2 

            d "В моём доме."

            hide draco neutral2

            show herm neutral 

            h "И почему-то единственный человек в этом доме, который сейчас действительно пытается найти вашу семейную реликвию, — это я."

            hide herm neutral

            show draco smile2 

            "Несколько секунд они смотрели друг на друга."

            d "Продолжай, ищейка."

            hide draco smile2

            show herm neutral 

            h "С удовольствием."

            "Гермиона снова посмотрела на пергамент."

            "Через несколько секунд её раздражение уступило место логике."

            h "Впрочем..."

            h "Версия с Нарциссой действительно слабая."

            h "Ей не было смысла прятать в доме опасный артефакт, когда она знала, что Мэнор будут обыскивать."

            hide herm neutral

            show draco smile2 

            d "Как приятно иногда оказаться правым."

            hide draco smile2

            show herm neutral 

            h "Я передумала."

            h "Возвращаем."

            hide herm neutral

            show draco neutral2 

            d "Грейнджер."

            hide draco neutral2

            show herm neutral 

            h "Малфой."

            stop music fadeout 3.0

            play music "audio/Candlelit Tension.mp3" loop fadein 3.0






    # --- ПРОДОЛЖЕНИЕ РЕКОНСТРУКЦИИ ---

    "Имя Нарциссы на пергаменте потускнело."

    hide draco neutral2

    show herm neutral 

    h "Теперь авроры."

    h "Где они находились после того, как Нарцисса поднялась наверх?"

    hide herm neutral

    show mippy neutral 

    m "Несколько были внизу, мисс."

    m "В главном холле."

    m "Другие осматривали комнаты."

    hide mippy neutral

    show herm neutral 

    h "Они могли видеть, кто поднимался к Люциусу?"

    hide herm neutral

    show draco neutral2 

    d "Не из главного холла."

    hide draco neutral2

    show herm neutral 

    h "Почему?"

    hide herm neutral

    show draco neutral2 

    d "Спальня отца находится в западном крыле."

    d "Из холла туда ведут две лестницы."

    d "Но последний участок коридора из нижнего этажа не просматривается."

    hide draco neutral2

    show herm neutral 

    h "Значит, если авроры оставались внизу..."

    hide herm neutral

    show draco neutral2 

    d "...они не могли видеть западную галерею."

    hide draco neutral2

    show herm neutral 

    "Гермиона подняла на него глаза."

    "Драко тоже посмотрел на неё."

    "Пауза длилась всего мгновение."

    h "Именно."

    hide germ neutral

    "Она снова склонилась над пергаментом."

    "Она снова склонилась над пергаментом."

    "Почти одновременно Драко потянулся к той же отметке."

    "Его рука легла на стол рядом с её рукой."

    "Слишком близко."

    "Костяшки их пальцев соприкоснулись."

    "Никто не отстранился сразу."

    "Гермиона продолжала смотреть на пергамент."

    "Драко, кажется, тоже."

    "Через несколько секунд он всё-таки убрал руку."

    "Совершенно обычное случайное прикосновение."

    "Почему-то Гермиона его заметила."

    "Она прочистила горло."


    # --- ПОСЛЕДНИЕ ЧАСЫ ЛЮЦИУСА ---

    h "Хорошо."

    h "Теперь сам Люциус."

    h "Миппи, когда ты в последний раз видела его живым?"

    hide herm neutral

    show mippy neutral 

    m "Вечером, мисс."

    m "Миппи приносила лекарства."

    m "Потом мастер Люциус попросил оставить с ним Тибби."

    hide mippy neutral

    show herm neutral 

    h "И после этого ты больше не входила?"

    hide herm neutral

    show mippy neutral 

    m "Нет, мисс."

    hide mippy neutral

    show herm neutral 

    h "А трость?"

    hide herm neutral

    show mippy neutral 

    "Миппи нахмурилась."

    m "Миппи помнит её возле кресла."

    hide mippy neutral

    show herm neutral 

    h "Когда?"

    hide herm neutral

    show mippy neutral 

    m "Днём."

    hide mippy neutral

    show herm neutral 

    h "А вечером?"

    hide herm neutral

    show mippy neutral 

    "Домовичка задумалась дольше."

    m "Миппи не помнит, мисс."

    hide mippy neutral

    show herm neutral 

    "Гермиона поставила на линии ещё одну отметку."

    h "Значит, днём трость точно находилась в комнате."

    h "А после этого мы её след теряем."

    hide herm neutral

    show draco neutral2 

    d "И единственным человеком, который постоянно находился рядом с отцом, был Тибби."

    hide draco neutral2

    show herm neutral 

    "Гермиона посмотрела на имя домовика."

    "Но пока это ничего не доказывало."

    h "Что происходило после смерти Люциуса?"

    hide herm neutral

    show mippy neutral 

    m "Тибби пришёл за Миппи."

    m "Сказал, что мастер Люциус больше не дышит."

    m "Миппи побежала за госпожой Нарциссой."

    hide mippy neutral

    show herm neutral 

    h "А Тибби?"

    hide herm neutral

    show mippy neutral 

    m "Миппи не знает."

    hide mippy neutral

    show herm neutral 

    h "Он пошёл с тобой?"

    hide herm neutral

    show mippy neutral 

    m "Нет, мисс."

    h "Остался возле Люциуса?"

    m "Миппи не видела."

    hide mippy neutral

    show herm neutral 

    "Гермиона провела кончиком пера по линии."

    "Между смертью Люциуса и моментом, когда в спальню начали приходить остальные, оставался небольшой пробел."

    "И никто из присутствующих сейчас не мог сказать, что происходило у его двери в это время."

    hide herm neutral

    show draco neutral2 

    d "Ты думаешь о Тибби."

    hide draco neutral2

    show herm neutral 

    h "Я думаю о временном промежутке."

    h "Это не одно и то же."

    hide herm neutral

    show draco neutral2 

    d "Почти убедительно."

    hide draco neutral2

    show herm neutral 

    h "Нам нужен человек, который видел коридор."

    "Гермиона снова посмотрела на схему."

    h "Кто находился возле спальни Люциуса всю ночь?"

    hide herm neutral

    show draco neutral2 

    "Драко нахмурился."

    d "Никто."

    "Он замолчал."

    "Потом выражение его лица изменилось."

    d "Хотя..."

    hide draco neutral2

    show herm neutral 

    h "Что?"

    hide herm neutral

    show draco neutral2 

    d "У двери спальни отца висит портрет."

    hide draco neutral2

    show herm neutral 

    "Гермиона медленно подняла голову."

    h "Портрет?"

    hide herm neutral

    show draco neutral2 

    d "Моего прадеда."

    hide draco neutral2

    show herm neutral 

    h "И ты вспоминаешь об этом только сейчас?"

    hide herm neutral

    show draco smile2 

    d "В своё оправдание могу сказать, что я стараюсь вспоминать о прадеде как можно реже."

    hide draco smile2

    show herm neutral 

    h "Он разговаривает?"

    hide herm neutral

    show draco neutral2 

    d "Со мной — да."

    d "С Министерством..."

    "Он задумался."

    d "Скорее всего, предпочтёт умереть второй раз."

    hide draco neutral2

    show herm neutral 

    "Гермиона уже поднималась из-за стола."

    h "Прекрасно."

    h "Тогда идём знакомиться с твоим прадедом."

    hide herm neutral

    show draco smile2 

    d "Не говори потом, что я тебя не предупреждал."

    hide draco smile2

    stop music fadeout 3.0


    jump scene_09_portrait